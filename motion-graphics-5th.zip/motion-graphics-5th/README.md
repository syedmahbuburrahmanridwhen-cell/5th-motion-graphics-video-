# 5th motion graphics video (Remotion)

1. `npm install`
2. `npx remotion studio`            (Composition: Main)
3. `npx remotion render src/index.ts Main out/video.mp4`

- Optional: put the voiceover at `public/voiceover.mp3` — it plays in Studio (flags in `src/config.ts`).
- All timing comes from `5th_motion_graphics_video.srt` → `src/cues.ts` (`npm run srt` regenerates it).
- Colors / fonts / easings / springs: `src/theme.ts`. SFX are in `public/sfx/` (`npm run sfx` re-synthesizes them).
