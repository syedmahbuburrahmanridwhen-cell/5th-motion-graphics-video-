// Deterministic SFX synthesis -> public/sfx/*.wav (16-bit mono, 44.1 kHz). No downloads, no music, no voice.
// Modern UI / motion-graphics set: pop, click, whoosh, swish, chime, thud.
import fs from "node:fs";
import path from "node:path";

const SR = 44100;
const OUT = new URL("../public/sfx/", import.meta.url).pathname;
fs.mkdirSync(OUT, { recursive: true });

// deterministic noise
let seed = 1234567;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
const N = (sec) => Math.floor(sec * SR);

const lowpass = (x, fc) => { const a = 1 - Math.exp((-2 * Math.PI * fc) / SR); let y = 0; return x.map((v) => (y += a * (v - y))); };
const highpass = (x, fc) => { const a = Math.exp((-2 * Math.PI * fc) / SR); let py = 0, px = 0; return x.map((v) => { const y = a * (py + v - px); px = v; py = y; return y; }); };
// time-varying band-pass (RBJ biquad, coefficients per sample)
const bandpass = (x, freqFn, Q) => {
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  return x.map((v, i) => {
    const f0 = freqFn(i / x.length), w = (2 * Math.PI * f0) / SR, al = Math.sin(w) / (2 * Q), c = Math.cos(w);
    const b0 = al, b2 = -al, a0 = 1 + al, a1 = -2 * c, a2 = 1 - al;
    const y = (b0 * v + b2 * x2 - a1 * y1 - a2 * y2) / a0;
    x2 = x1; x1 = v; y2 = y1; y1 = y; return y;
  });
};
const env = (len, atk, tau) => Array.from({ length: len }, (_, i) => { const t = i / SR; return Math.min(1, t / atk) * Math.exp(-t / tau); });
// very small reverb (4 combs + 1 allpass), short tail
const reverb = (x, mix = 0.1) => {
  const delays = [0.0297, 0.0371, 0.0411, 0.0437].map((d) => Math.floor(d * SR));
  const out = new Float64Array(x.length + N(0.12));
  const src = new Float64Array(out.length); x.forEach((v, i) => (src[i] = v));
  const wet = new Float64Array(out.length);
  for (const d of delays) { const buf = new Float64Array(out.length); for (let i = 0; i < out.length; i++) { buf[i] = src[i] + (i >= d ? buf[i - d] * 0.32 : 0); wet[i] += buf[i] * 0.25; } }
  for (let i = 0; i < out.length; i++) out[i] = src[i] * (1 - mix * 0.5) + wet[i] * mix * 2;
  return Array.from(out);
};
const fade = (x, inS, outS) => x.map((v, i) => { const fi = Math.min(1, i / N(inS || 0.0001)), fo = Math.min(1, (x.length - i) / N(outS)); return v * fi * fo; });

const sounds = {
  pop: () => { // quick downward pitch sine + tiny noise transient
    const n = N(0.28), e = env(n, 0.004, 0.07); let ph = 0;
    const s = Array.from({ length: n }, (_, i) => { const t = i / SR, f = 180 + 360 * Math.exp(-t / 0.035); ph += (2 * Math.PI * f) / SR; return Math.sin(ph) * e[i]; });
    const tr = lowpass(Array.from({ length: n }, (_, i) => rnd() * Math.exp(-i / SR / 0.004) * 0.25), 3500);
    return s.map((v, i) => v + tr[i]);
  },
  click: () => { // high-passed short noise burst + tiny tick
    const n = N(0.14), e = env(n, 0.001, 0.014);
    const nz = highpass(Array.from({ length: n }, () => rnd()), 2600).map((v, i) => v * e[i]);
    const tick = Array.from({ length: n }, (_, i) => Math.sin((2 * Math.PI * 1700 * i) / SR) * Math.exp(-i / SR / 0.006) * 0.35);
    return nz.map((v, i) => v + tick[i]);
  },
  whoosh: () => { // band-pass noise sweep, fade in / fade out
    const n = N(0.62), raw = Array.from({ length: n }, () => rnd());
    const bp = bandpass(raw, (p) => 380 * Math.pow(9, p), 1.1);
    return bp.map((v, i) => { const p = i / n; return v * Math.pow(Math.sin(Math.PI * Math.pow(p, 0.7)), 2); });
  },
  swish: () => { // shorter, lighter rising sweep for text entries
    const n = N(0.36), raw = Array.from({ length: n }, () => rnd());
    const bp = bandpass(raw, (p) => 1100 * Math.pow(3, p), 1.6);
    return bp.map((v, i) => { const p = i / n; return v * Math.pow(Math.sin(Math.PI * p), 2) * 0.8; });
  },
  chime: () => { // soft pluck/chime: few partials with slightly inharmonic overtones
    const n = N(0.34), base = 880, parts = [[1, 1, 0.14], [2.01, 0.34, 0.09], [3.02, 0.16, 0.06], [4.16, 0.07, 0.04]];
    return Array.from({ length: n }, (_, i) => { const t = i / SR; let v = 0; for (const [m, a, tau] of parts) v += Math.sin(2 * Math.PI * base * m * t) * a * Math.exp(-t / tau); return v * Math.min(1, t / 0.006); });
  },
  thud: () => { // very light soft thud for the hook / key message
    const n = N(0.3); let ph = 0;
    const s = Array.from({ length: n }, (_, i) => { const t = i / SR, f = 48 + 52 * Math.exp(-t / 0.05); ph += (2 * Math.PI * f) / SR; return Math.sin(ph) * Math.min(1, t / 0.008) * Math.exp(-t / 0.11); });
    return lowpass(s, 260);
  },
};

const TARGET_RMS = 0.1, PEAK_CAP = 0.9;
const report = [];
for (const [name, gen] of Object.entries(sounds)) {
  seed = 1234567;
  let x = gen();
  x = lowpass(x, 9000);        // soften
  x = reverb(x, name === "click" ? 0.05 : 0.1); // very small room
  x = fade(x, 0.0, 0.03);
  // trim trailing near-silence
  let last = x.length - 1; while (last > 0 && Math.abs(x[last]) < 1e-4) last--; x = x.slice(0, Math.min(x.length, last + N(0.02)));
  const active = x.filter((v) => Math.abs(v) > 1e-3);
  const rms = Math.sqrt(active.reduce((s, v) => s + v * v, 0) / Math.max(1, active.length));
  const peak0 = Math.max(...x.map(Math.abs));
  const g = Math.min(TARGET_RMS / rms, PEAK_CAP / peak0);
  x = x.map((v) => v * g);
  const buf = Buffer.alloc(44 + x.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + x.length * 2, 4); buf.write("WAVEfmt ", 8); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34); buf.write("data", 36); buf.writeUInt32LE(x.length * 2, 40);
  let clipped = 0;
  x.forEach((v, i) => { const c = Math.max(-1, Math.min(1, v)); if (Math.abs(v) >= 0.999) clipped++; buf.writeInt16LE(Math.round(c * 32767), 44 + i * 2); });
  fs.writeFileSync(path.join(OUT, `${name}.wav`), buf);
  const peak = Math.max(...x.map(Math.abs)), rmsF = Math.sqrt(x.reduce((s, v) => s + v * v, 0) / x.length);
  report.push({ name, sec: +(x.length / SR).toFixed(3), peakDb: +(20 * Math.log10(peak)).toFixed(1), activeRms: +(rms * g).toFixed(3), clipped });
}
console.table(report);
