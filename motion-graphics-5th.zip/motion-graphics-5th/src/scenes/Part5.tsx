import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { useScene } from "../timing";
import { theme } from "../theme";
import { Avatar, IconBell, IconBulb, IconCheck, IconKey, IconLink, IconPin, IconSpark } from "../components/Icons";
import { Bar, Glass, Pill, T } from "../components/Glass";
import { WordReveal, clamp, prog, useBreathe, useFloat } from "../components/Motion";
import { Sfx } from "../components/Sfx";

const pop = (frame: number, fps: number, delay: number, preset: "snappy" | "bouncy" | "smooth" = "snappy") =>
  spring({ frame: frame - delay, fps, config: theme.spring[preset] });
const enter = (p: number, dist = 50, from = 0.92): React.CSSProperties => ({ opacity: interpolate(p, [0, 0.5], [0, 1], clamp), transform: `translateY(${interpolate(p, [0, 1], [dist, 0])}px) scale(${interpolate(p, [0, 1], [from, 1])})` });

/* ───────────── 13. ARRIVE — Minimal statement → people converge (cues 32–34) ───────────── */
const START = [{ x: 170, y: 230 }, { x: 150, y: 820 }, { x: 1740, y: 200 }, { x: 1780, y: 780 }, { x: 960, y: 1010 }];
const PIN = { x: 960, y: 500 };
const bez = (a: number, b: number, c: number, t: number) => (1 - t) * (1 - t) * a + 2 * (1 - t) * t * b + t * t * c;

const ArriveBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  // Phase A
  const tRing = Math.max(0, s.at(32, 0.0));
  const wA = [s.at(32, 0.28), s.at(32, 0.43), s.at(32, 0.57), s.at(32, 0.71)].map((v) => Math.max(0, v));
  const outA = prog(frame, s.at(33, 0.0) - 6, s.at(33, 0.0) + 4, theme.ease.in);
  const ringD = prog(frame, tRing, tRing + 26, theme.ease.inOut);
  const chkD = prog(frame, tRing + 22, tRing + 38);
  const br = useBreathe(0.012, 20);
  // Phase B
  const tPill = Math.max(0, s.at(33, 0.15));
  const tPin = Math.max(0, s.at(33, 0.5));
  const arrive = [0, 1, 2, 3, 4].map((k) => s.spread(34, k, 5, 0) );
  const tLab = s.at(34, 0.1);
  const pinP = pop(frame, fps, tPin, "bouncy");
  const R = 2 * Math.PI * 150;
  return (
    <AbsoluteFill>
      {/* Phase A */}
      <div style={{ position: "absolute", inset: 0, opacity: 1 - outA, transform: `scale(${1 + outA * 0.06})`, filter: `blur(${outA * 6}px)` }}>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          <circle cx={960} cy={400} r={150} fill="none" stroke={theme.colors.hero} strokeWidth={18} strokeLinecap="round" strokeDasharray={R} strokeDashoffset={R * (1 - ringD)} transform="rotate(-90 960 400)" style={{ filter: `drop-shadow(0 0 24px ${theme.colors.heroGlow})` }} />
        </svg>
        <div style={{ position: "absolute", left: 960 - 80, top: 400 - 80, transform: `scale(${br})` }}><IconCheck size={160} color={theme.colors.text} stroke={4.5} draw={chkD} /></div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 640 }}>
          <WordReveal words={["প্রমাণ", "করার", "কিছু", "নেই"]} delays={wA} size={128} align="center" highlight={{ 3: theme.colors.accent }} />
        </div>
      </div>
      {/* Phase B */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 70, display: "flex", justifyContent: "center", opacity: prog(frame, tPill, tPill + 10), transform: `translateY(${(1 - prog(frame, tPill, tPill + 14)) * -30}px)` }}>
        <Pill size={76} bg="transparent" color={theme.colors.accent} style={{ borderColor: theme.colors.accent, padding: "8px 56px", whiteSpace: "nowrap" }}>professional service</Pill>
      </div>
      {frame >= tPin - 2 && (
        <div style={{ position: "absolute", left: PIN.x - 110, top: PIN.y - 110, width: 220, height: 220, transform: `scale(${pinP * br})`, opacity: interpolate(pinP, [0, 0.4], [0, 1], clamp) }}>
          <div style={{ position: "absolute", inset: -40, borderRadius: "50%", border: `3px dashed ${theme.colors.accent}`, opacity: 0.45, transform: `rotate(${-frame * 0.7}deg)` }} />
          <div style={{ width: 220, height: 220, borderRadius: "50%", background: `radial-gradient(circle at 35% 30%, #8F82F5, ${theme.colors.hero} 58%, #4A3DB8)`, boxShadow: theme.shadow.heroGlow, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <IconPin size={120} color={theme.colors.white} />
          </div>
        </div>
      )}
      {START.map((st, k) => {
        const T0 = arrive[k] - 18;
        const q = prog(frame, T0, T0 + 26, theme.ease.inOut);
        const ang = (-90 + k * 72) * (Math.PI / 180);
        const end = { x: PIN.x + 300 * Math.cos(ang), y: PIN.y + 250 * Math.sin(ang) };
        const ctrl = { x: (st.x + end.x) / 2 + (k % 2 ? 160 : -160), y: (st.y + end.y) / 2 - 80 };
        const x = bez(st.x, ctrl.x, end.x, q), y = bez(st.y, ctrl.y, end.y, q);
        const vis = prog(frame, T0 - 8, T0 - 2);
        const arr = pop(frame, fps, T0 + 26, "bouncy");
        return (
          <div key={k} style={{ position: "absolute", left: x - 55, top: y - 55, opacity: vis, transform: `scale(${0.8 + 0.2 * q + 0.1 * Math.sin(Math.PI * Math.min(1, arr))})` }}>
            <Avatar size={110} tint={theme.colors.textDim} style={{ borderColor: q > 0.98 ? theme.colors.accent : theme.colors.border, boxShadow: q > 0.98 ? theme.shadow.accentGlow : "none" }} />
          </div>
        );
      })}
      <div style={{ position: "absolute", left: 0, right: 0, top: 850 }}>
        <WordReveal words={["সঠিক", "জায়গায়"]} delays={[tLab, tLab + 4]} size={96} align="center" highlight={{ 1: theme.colors.accent }} />
      </div>
      <Sfx name="pop" at={tRing} rate={0.95} />
      <Sfx name="click" at={tRing + 24} />
      <Sfx name="swish" at={tPill} />
      <Sfx name="pop" at={tPin} rate={1.06} />
      <Sfx name="pop" at={arrive[0] + 8} rate={1.1} vol={0.8} />
      <Sfx name="pop" at={arrive[4] + 8} rate={1.18} vol={0.8} />
    </AbsoluteFill>
  );
};
export const SceneArrive: React.FC = () => (
  <SceneShell id="arrive"><ArriveBody /></SceneShell>
);

/* ───────────── 14. REQUESTS — Glass cards (cues 35–36) ───────────── */
const AvatarStack: React.FC<{ p: number }> = ({ p }) => (
  <div style={{ display: "flex", opacity: p }}>
    {[0, 1, 2].map((i) => <Avatar key={i} size={70} tint={theme.colors.textDim} style={{ marginLeft: i ? -22 : 0, transform: `scale(${0.6 + 0.4 * p})` }} />)}
  </div>
);
const RequestsBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tT = Math.max(0, s.at(35, 0));
  const c1 = Math.max(0, s.at(35, 0.75));
  const c2 = Math.max(0, s.at(36, 0.1));
  const p1 = pop(frame, fps, c1, "smooth"), p2 = pop(frame, fps, c2, "smooth");
  const g1 = Math.max(0, 1 - prog(frame, c1 + 4, c1 + 34)), g2 = Math.max(0, 1 - prog(frame, c2 + 4, c2 + 34));
  const f1 = useFloat(5, 26), f2 = useFloat(5, 26, 2);
  const card = (key: string, p: number, g: number, f: number, left: number, icon: React.ReactNode, label: string, size: number) => (
    <div key={key} style={{ position: "absolute", left, top: 360 + f, ...enter(p, 70, 0.9) }}>
      <Glass w={760} h={440} r={52} strong style={{ padding: 52, borderColor: g > 0.3 ? theme.colors.hero : theme.colors.border, boxShadow: `${theme.shadow.card}${g > 0.02 ? `, 0 0 ${70 * g}px rgba(108,92,231,${0.65 * g})` : ""}` }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div style={{ width: 160, height: 160, borderRadius: 46, background: theme.colors.bgAlt, border: `1.5px solid ${theme.colors.border}`, display: "flex", alignItems: "center", justifyContent: "center" }}>{icon}</div>
          <AvatarStack p={prog(frame, (key === "a" ? c1 : c2) + 10, (key === "a" ? c1 : c2) + 24)} />
        </div>
        <T size={size} style={{ marginTop: 46, whiteSpace: "nowrap" }}>{label}</T>
        <Bar w={360} h={14} style={{ marginTop: 22 }} />
      </Glass>
    </div>
  );
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 0, right: 0, top: 110 }}>
        <WordReveal words={["অনেকেই", "অনুরোধ", "করেছেন"]} delay={tT} per={5} size={104} align="center" highlight={{ 1: theme.colors.accent }} />
      </div>
      {card("a", p1, g1, f1, 180, <IconBulb size={100} color={theme.colors.accent} draw={prog(frame, c1, c1 + 22)} />, "Pro tips", 92)}
      {card("b", p2, g2, f2, 980, <IconSpark size={96} color={theme.colors.accent} />, "Amazing AI tools", 78)}
      <Sfx name="swish" at={tT} />
      <Sfx name="pop" at={c1} />
      <Sfx name="pop" at={c2} rate={1.08} vol={0.95} />
    </AbsoluteFill>
  );
};
export const SceneRequests: React.FC = () => (
  <SceneShell id="requests"><RequestsBody /></SceneShell>
);

/* ───────────── 15. TEASER — next video, free pro tips & secret tools (cues 37–38) ───────────── */
const TeaserBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tT = [s.at(37, 0.35), s.at(37, 0.5), s.at(37, 0.65)].map((v) => Math.max(0, v));
  const tV = Math.max(0, s.at(37, 0.3));
  const tFree = Math.max(0, s.at(37, 0.8));
  const tC1 = Math.max(0, s.at(38, 0.1));
  const tC2 = Math.max(0, s.at(38, 0.55));
  const vp = pop(frame, fps, tV, "smooth");
  const fp = pop(frame, fps, tFree, "bouncy");
  const c1 = pop(frame, fps, tC1, "snappy"), c2 = pop(frame, fps, tC2, "snappy");
  const fl = useFloat(5, 26);
  const prog2 = interpolate(frame, [tV + 10, tV + 140], [0.04, 0.34], { easing: theme.ease.out, ...clamp });
  const chip = (p: number, top: number, icon: React.ReactNode, label: string) => (
    <div style={{ position: "absolute", left: 1170, top: top - fl, opacity: interpolate(p, [0, 0.5], [0, 1], clamp), transform: `translateX(${interpolate(p, [0, 1], [-260, 0])}px) scale(${interpolate(p, [0, 1], [0.8, 1])})` }}>
      <Glass w={620} h={180} r={44} strong style={{ display: "flex", alignItems: "center", padding: "0 44px", gap: 34 }}>
        {icon}
        <T size={76} style={{ whiteSpace: "nowrap" }}>{label}</T>
      </Glass>
    </div>
  );
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 130, top: 100 }}>
        <WordReveal words={["পরের", "video", "থেকে"]} delays={tT} size={100} highlight={{ 1: theme.colors.accent }} />
      </div>
      <div style={{ position: "absolute", left: 130, top: 290 + fl, perspective: 2000, ...enter(vp, 60, 0.92) }}>
        <div style={{ transform: "rotateY(-7deg)", transformOrigin: "0 50%" }}>
          <Glass w={960} h={540} r={48} strong style={{ overflow: "hidden" }}>
            <div style={{ position: "absolute", inset: 0, background: `linear-gradient(135deg, ${theme.colors.bgAlt}, ${theme.colors.hero}33 60%, ${theme.colors.accent}22)` }} />
            <div style={{ position: "absolute", left: 48, top: 48, display: "flex", gap: 14 }}><Bar w={220} h={18} color={theme.colors.textDim} /></div>
            <div style={{ position: "absolute", left: "50%", top: "50%", width: 168, height: 168, marginLeft: -84, marginTop: -84, borderRadius: "50%", background: theme.colors.surfaceStrong, border: `3px solid ${theme.colors.text}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <div style={{ width: 0, height: 0, borderTop: "34px solid transparent", borderBottom: "34px solid transparent", borderLeft: `56px solid ${theme.colors.text}`, marginLeft: 14 }} />
            </div>
            <div style={{ position: "absolute", left: 48, right: 48, bottom: 48, height: 14, borderRadius: 14, background: theme.colors.textFaint }}>
              <div style={{ width: `${prog2 * 100}%`, height: "100%", borderRadius: 14, background: theme.colors.accent }} />
            </div>
          </Glass>
        </div>
        <div style={{ position: "absolute", right: -50, top: -50, padding: "6px 52px 10px", borderRadius: 80, background: theme.colors.hero, boxShadow: theme.shadow.heroGlow, transform: `scale(${fp}) rotate(${interpolate(fp, [0, 1], [-24, 6])}deg)`, opacity: interpolate(fp, [0, 0.3], [0, 1], clamp) }}>
          <T size={92} color={theme.colors.white}>free</T>
        </div>
      </div>
      {chip(c1, 330, <IconBulb size={84} color={theme.colors.accent} draw={prog(frame, tC1, tC1 + 20)} />, "Pro tips")}
      {chip(c2, 590, <IconKey size={84} color={theme.colors.accent} draw={prog(frame, tC2, tC2 + 20)} />, "Secret tools")}
      <Sfx name="pop" at={tV} />
      <Sfx name="pop" at={tFree} rate={1.14} vol={0.9} />
      <Sfx name="swish" at={tC1} />
      <Sfx name="chime" at={tC2} rate={1.04} vol={0.9} />
    </AbsoluteFill>
  );
};
export const SceneTeaser: React.FC = () => (
  <SceneShell id="teaser"><TeaserBody /></SceneShell>
);

/* ───────────── 16. FOLLOW — page card + follow click (cues 39–40) ───────────── */
const Cursor: React.FC<{ x: number; y: number; press: number }> = ({ x, y, press }) => (
  <svg width={70} height={86} viewBox="0 0 28 34" style={{ position: "absolute", left: x, top: y, transform: `scale(${1 - press * 0.12})`, filter: "drop-shadow(0 6px 10px rgba(0,0,0,0.5))" }}>
    <path d="M3 2l20 14-9 1.5 5 9.5-4 2-5-9.5L3 25z" fill={theme.colors.white} stroke={theme.colors.bg} strokeWidth={2} strokeLinejoin="round" />
  </svg>
);
const FollowBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tM = [0, 1, 2, 3].map((k) => Math.max(0, s.at(39, (0.55 * k) / 4)));
  const tCard = Math.max(0, s.at(39, 0.2));
  const tF = [Math.max(0, s.at(40, 0)), Math.max(0, s.at(40, 0.15))];
  const clickAt = s.at(40, 0.5);
  const cp = pop(frame, fps, tCard, "smooth");
  const press = interpolate(frame, [clickAt - 3, clickAt, clickAt + 4], [0, 1, 0], clamp);
  const done = pop(frame, fps, clickAt + 2, "bouncy");
  const bell = pop(frame, fps, clickAt + 12, "bouncy");
  const ripple = prog(frame, clickAt, clickAt + 18);
  const move = prog(frame, clickAt - 34, clickAt - 2, theme.ease.inOut);
  const away = prog(frame, clickAt + 8, clickAt + 26);
  const cx = 1560 + (1370 - 1560) * move + 150 * away, cy = 960 + (700 - 960) * move + 120 * away;
  const fl = useFloat(4, 28);
  const BTN = { x: 1410, y: 720 };
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 130, top: 230, width: 900 }}>
        <WordReveal words={["Miss", "না", "করতে", "চাইলে"]} delays={tM} per={4} size={100} highlight={{ 0: theme.colors.accent }} />
        <div style={{ marginTop: 40 }}>
          <WordReveal words={["Follow"]} delays={[tF[0]]} size={230} color={theme.colors.text} />
          <WordReveal words={["দিয়ে", "সাথে", "থাকুন"]} delays={[tF[1], tF[1] + 4, tF[1] + 8]} size={96} weight={theme.fonts.semi} color={theme.colors.textDim} />
        </div>
      </div>
      <div style={{ position: "absolute", left: 1060, top: 220 + fl, ...enter(cp, 60, 0.92) }}>
        <Glass w={700} h={640} r={52} strong style={{ overflow: "visible" }}>
          <div style={{ height: 200, borderRadius: "52px 52px 0 0", background: `linear-gradient(120deg, ${theme.colors.hero}55, ${theme.colors.accent}26)`, borderBottom: `1.5px solid ${theme.colors.border}` }} />
          <div style={{ position: "absolute", left: 56, top: 120 }}><Avatar size={170} tint={theme.colors.textDim} style={{ borderWidth: 6, borderColor: theme.colors.bg }} /></div>
          <div style={{ position: "absolute", left: 56, top: 316, display: "flex", flexDirection: "column", gap: 18 }}>
            <Bar w={300} h={24} color={theme.colors.text} style={{ opacity: 0.85 }} />
            <Bar w={200} h={16} color={theme.colors.textDim} />
          </div>
          {/* follow button */}
          <div style={{ position: "absolute", left: BTN.x - 1060 - 190, top: BTN.y - 220 - fl * 0 - 55, width: 380, height: 110, borderRadius: 55, background: done > 0.5 ? theme.colors.surfaceStrong : theme.colors.hero, border: done > 0.5 ? `2px solid ${theme.colors.accent}` : "none", boxShadow: done > 0.5 ? "none" : theme.shadow.heroGlow, display: "flex", alignItems: "center", justifyContent: "center", gap: 16, transform: `scale(${1 - press * 0.06})` }}>
            {done > 0.5 ? <><IconCheck size={52} color={theme.colors.accent} draw={done} /><T size={52} color={theme.colors.text}>Following</T></> : <T size={56} color={theme.colors.white}>Follow</T>}
          </div>
          <div style={{ position: "absolute", left: BTN.x - 1060 + 190 - 55 + 90, top: BTN.y - 220 - 55, width: 110, height: 110, borderRadius: 30, background: theme.colors.bgAlt, border: `1.5px solid ${theme.colors.border}`, display: "flex", alignItems: "center", justifyContent: "center", opacity: bell, transform: `scale(${bell}) rotate(${Math.sin(frame / 3) * 10 * (1 - prog(frame, clickAt + 12, clickAt + 40))}deg)` }}>
            <IconBell size={60} color={theme.colors.accent} draw={bell} />
          </div>
          {ripple > 0 && ripple < 1 && <div style={{ position: "absolute", left: BTN.x - 1060 - 190 - 30 * ripple, top: BTN.y - 220 - 55 - 30 * ripple, width: 380 + 60 * ripple, height: 110 + 60 * ripple, borderRadius: 80, border: `3px solid ${theme.colors.accent}`, opacity: 1 - ripple }} />}
        </Glass>
      </div>
      <Cursor x={cx} y={cy} press={press} />
      <Sfx name="pop" at={tCard} />
      <Sfx name="swish" at={tF[0]} />
      <Sfx name="click" at={clickAt} />
      <Sfx name="chime" at={clickAt + 12} rate={1.1} vol={0.85} />
    </AbsoluteFill>
  );
};
export const SceneFollow: React.FC = () => (
  <SceneShell id="follow"><FollowBody /></SceneShell>
);

/* ───────────── 17. END — link in the comment box, thank you (cues 41–42) ───────────── */
const EndBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tT = [s.at(41, 0.0), s.at(41, 0.28), s.at(41, 0.52)].map((v) => Math.max(0, v));
  const tBox = Math.max(0, s.at(41, 0.35));
  const tLink = Math.max(0, s.at(41, 0.7));
  const tThanks = s.at(42, 0.78);
  const bp = pop(frame, fps, tBox, "smooth");
  const lp = pop(frame, fps, tLink, "bouncy");
  const tp = pop(frame, fps, tThanks, "bouncy");
  const nudge = prog(frame, s.at(42, 0.2), s.at(42, 0.3));
  const bob = Math.sin(frame / 5) * 8 * nudge;
  const fl = useFloat(4, 28);
  const br = useBreathe(0.012, 18);
  const sparkle = (x: number, y: number, size: number, ph: number) => {
    const sp = pop(frame, fps, tThanks + 6 + ph * 3, "bouncy");
    return <div style={{ position: "absolute", left: x, top: y, opacity: sp * (0.6 + 0.4 * Math.sin(frame / 6 + ph)), transform: `scale(${sp}) rotate(${frame * 1.2 + ph * 40}deg)` }}><IconSpark size={size} color={ph % 2 ? theme.colors.accent : theme.colors.text} /></div>;
  };
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 130, top: 120 }}>
        <WordReveal words={["আমার", "website", "link"]} delays={tT} size={96} highlight={{ 1: theme.colors.accent }} />
      </div>
      <div style={{ position: "absolute", left: 130, top: 370 + fl, ...enter(bp, 60, 0.94) }}>
        <Glass w={960} h={470} r={48} strong>
          <div style={{ display: "flex", alignItems: "center", gap: 22, padding: "34px 44px" }}>
            <Avatar size={84} tint={theme.colors.textDim} />
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}><Bar w={260} h={20} color={theme.colors.textDim} /><Bar w={150} h={12} /></div>
            <div style={{ marginLeft: "auto" }}><Pill size={34}>comment box</Pill></div>
          </div>
          <div style={{ margin: "0 44px", padding: "30px 36px", borderRadius: 30, background: theme.colors.surface, border: `1.5px solid ${theme.colors.border}`, display: "flex", flexDirection: "column", gap: 28 }}>
            <Bar w={520} h={16} color={theme.colors.textDim} />
            <div style={{ display: "flex", alignItems: "center", gap: 22, alignSelf: "flex-start", padding: "16px 40px 16px 30px", borderRadius: 60, background: theme.colors.hero, boxShadow: theme.shadow.heroGlow, opacity: interpolate(lp, [0, 0.4], [0, 1], clamp), transform: `scale(${interpolate(lp, [0, 1], [0.8, 1]) * (1 + nudge * 0.03 * Math.sin(frame / 5))})`, transformOrigin: "0 50%" }}>
              <IconLink size={64} color={theme.colors.white} draw={lp} />
              <Bar w={330} h={20} color={theme.colors.white} style={{ opacity: 0.85 }} />
            </div>
          </div>
        </Glass>
      </div>
      <div style={{ position: "absolute", left: 1090, top: 400 + bob, opacity: nudge * (1 - tp), display: "none" }} />
      {/* ধন্যবাদ */}
      <div style={{ position: "absolute", left: 1110, top: 440, width: 700, display: "flex", justifyContent: "center", opacity: interpolate(tp, [0, 0.4], [0, 1], clamp), transform: `scale(${interpolate(tp, [0, 1], [0.7, 1]) * br}) translateY(${interpolate(tp, [0, 1], [60, 0])}px)` }}>
        <T size={190} style={{ textShadow: `0 0 70px ${theme.colors.heroGlow}`, whiteSpace: "nowrap" }}>ধন্যবাদ<span style={{ color: theme.colors.accent }}>।</span></T>
      </div>
      {sparkle(1130, 380, 70, 0)}
      {sparkle(1740, 400, 54, 1)}
      {sparkle(1700, 690, 64, 2)}
      {sparkle(1180, 700, 46, 3)}
      <Sfx name="swish" at={tT[0]} />
      <Sfx name="pop" at={tBox} />
      <Sfx name="chime" at={tLink} rate={0.98} />
      <Sfx name="chime" at={tThanks} rate={1.12} vol={0.9} />
    </AbsoluteFill>
  );
};
export const SceneEnd: React.FC = () => (
  <SceneShell id="end"><EndBody /></SceneShell>
);
