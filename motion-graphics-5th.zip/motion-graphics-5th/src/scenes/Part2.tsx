import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { useScene } from "../timing";
import { theme } from "../theme";
import { IconBrowser, IconCheck, IconCross, IconPlay, IconSpark } from "../components/Icons";
import { Bar, Glass, Pill, T } from "../components/Glass";
import { WordReveal, clamp, prog, useBreathe, useFloat } from "../components/Motion";
import { Sfx } from "../components/Sfx";

const pop = (frame: number, fps: number, delay: number, preset: "snappy" | "bouncy" | "smooth" = "snappy") =>
  spring({ frame: frame - delay, fps, config: theme.spring[preset] });

/* ───────────── 4. ADMIT — Hub-and-Spoke (cues 8–10) ───────────── */
const HUB = { x: 960, y: 640 };
const NODES = [{ x: 470, y: 330, key: "video" }, { x: 1450, y: 330, key: "website" }];

const AdmitBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const hub = Math.max(0, s.at(8, 0.3));
  const n1 = Math.max(0, s.at(8, 0.62));
  const n2 = Math.max(0, s.at(9, 0));
  const tag = Math.max(0, s.at(9, 0.55));
  const cap = Math.max(0, s.at(10, 0));
  const yes = Math.max(0, s.at(8, 0));
  const hp = pop(frame, fps, hub, "bouncy");
  const br = useBreathe(0.015, 20);
  const fl = useFloat(5, 26);
  const times = [n1, n2];
  return (
    <AbsoluteFill>
      {/* spokes */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        {NODES.map((n, i) => {
          const d = prog(frame, times[i] - 6, times[i] + 18);
          const len = Math.hypot(n.x - HUB.x, n.y - HUB.y);
          const t = ((frame - times[i] - 20) % 50) / 50;
          return (
            <g key={n.key}>
              <line x1={HUB.x} y1={HUB.y} x2={n.x} y2={n.y} stroke={theme.colors.accent} strokeOpacity={0.55} strokeWidth={4} strokeLinecap="round" strokeDasharray={`${len}`} strokeDashoffset={len * (1 - d)} />
              {frame > times[i] + 20 && <circle cx={HUB.x + (n.x - HUB.x) * t} cy={HUB.y + (n.y - HUB.y) * t} r={9} fill={theme.colors.accent} opacity={Math.sin(Math.PI * t)} />}
            </g>
          );
        })}
      </svg>
      {/* "হ্যাঁ," */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 70 }}>
        <WordReveal words={["হ্যাঁ,"]} delay={yes} size={120} align="center" color={theme.colors.accent} />
      </div>
      {/* nodes */}
      {NODES.map((n, i) => {
        const p = pop(frame, fps, times[i], "snappy");
        return (
          <div key={n.key} style={{ position: "absolute", left: n.x - 210, top: n.y - 140 + fl * (i ? -1 : 1), opacity: interpolate(p, [0, 0.5], [0, 1], clamp), transform: `scale(${interpolate(p, [0, 1], [0.7, 1])})` }}>
            <Glass w={420} h={280} r={40} strong style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 6 }}>
              {i === 0 ? <IconPlay size={128} color={theme.colors.accent} draw={prog(frame, times[i], times[i] + 22)} /> : <IconBrowser size={128} color={theme.colors.accent} draw={prog(frame, times[i], times[i] + 22)} />}
              <T size={66} weight={theme.fonts.heavy}>{i === 0 ? "Video" : "Website"}</T>
            </Glass>
          </div>
        );
      })}
      {/* অনেকাংশে tag */}
      <div style={{ position: "absolute", left: NODES[1].x - 150, top: NODES[1].y + 170, opacity: prog(frame, tag, tag + 10), transform: `translateY(${(1 - prog(frame, tag, tag + 14)) * 20}px)` }}>
        <Pill size={42} bg="transparent" color={theme.colors.accent} style={{ borderColor: theme.colors.accent }}>অনেকাংশে</Pill>
      </div>
      {/* hub (hero) */}
      <div style={{ position: "absolute", left: HUB.x - 150, top: HUB.y - 150, width: 300, height: 300, transform: `scale(${hp * br})`, opacity: interpolate(hp, [0, 0.4], [0, 1], clamp) }}>
        <div style={{ position: "absolute", inset: -46, borderRadius: "50%", border: `3px dashed ${theme.colors.accent}`, opacity: 0.5, transform: `rotate(${frame * 0.8}deg)` }} />
        <div style={{ width: 300, height: 300, borderRadius: 96, background: `linear-gradient(145deg, #8F82F5, ${theme.colors.hero} 55%, #4A3DB8)`, boxShadow: theme.shadow.heroGlow, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", transform: `rotate(${interpolate(hp, [0, 1], [-25, 0])}deg)` }}>
          <IconSpark size={100} color={theme.colors.white} />
          <T size={92} color={theme.colors.white} style={{ marginTop: -4 }}>AI</T>
        </div>
      </div>
      {/* caption */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 880 }}>
        <WordReveal words={["AI-এর", "সাহায্য", "নিই"]} delay={cap} per={4} size={96} align="center" highlight={{ 0: theme.colors.accent }} />
      </div>
      <Sfx name="pop" at={hub} rate={0.95} />
      <Sfx name="pop" at={n1} rate={1.06} vol={0.9} />
      <Sfx name="pop" at={n2} rate={0.98} vol={0.9} />
      <Sfx name="swish" at={cap} />
    </AbsoluteFill>
  );
};
export const SceneAdmit: React.FC = () => (
  <SceneShell id="admit"><AdmitBody /></SceneShell>
);

/* ───────────── 5. NOT PRO — Statement card + strike (cues 11–12) ───────────── */
const NotProBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const td = [Math.max(2, s.at(10, 0.7)), Math.max(5, s.at(10, 0.82)), Math.max(8, s.at(11, 0)), Math.max(11, s.at(11, 0.12))];
  const card = Math.max(0, s.at(11, 0.55));
  const w = [Math.max(card + 4, s.at(11, 0.8)), s.at(12, 0), s.at(12, 0.12)];
  const strikeAt = s.at(12, 0.3);
  const strike = prog(frame, strikeAt, strikeAt + 14, theme.ease.inOut);
  const dim = prog(frame, strikeAt + 6, strikeAt + 22);
  const badge = pop(frame, fps, strikeAt + 10, "bouncy");
  const cp = pop(frame, fps, card, "smooth");
  const br = useBreathe(0.006, 30);
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 0, right: 0, top: 130 }}>
        <WordReveal words={["আমি", "কখনোই", "দাবি", "করিনি"]} delays={td} size={104} align="center" highlight={{ 2: theme.colors.accent, 3: theme.colors.accent }} />
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 410, display: "flex", justifyContent: "center", opacity: interpolate(cp, [0, 0.5], [0, 1], clamp), transform: `translateY(${interpolate(cp, [0, 1], [50, 0])}px) scale(${interpolate(cp, [0, 1], [0.94, 1]) * br})` }}>
        <Glass w={1520} h={340} r={52} strong style={{ display: "flex", alignItems: "center", padding: "0 64px", gap: 44 }}>
          <div style={{ width: 160, height: 160, borderRadius: 44, background: theme.colors.bgAlt, border: `1.5px solid ${theme.colors.border}`, display: "flex", alignItems: "center", justifyContent: "center", opacity: 1 - dim * 0.5 }}>
            <IconPlay size={96} color={theme.colors.accent} draw={prog(frame, card, card + 20)} />
          </div>
          <div style={{ position: "relative", opacity: 1 - dim * 0.55 }}>
            <WordReveal words={["Professional", "Video", "Editor"]} delays={w} size={92} style={{ flexWrap: "nowrap" }} />
            <div style={{ position: "absolute", left: -18, top: "50%", height: 10, marginTop: -2, width: `calc(${strike * 100}% + ${36 * strike}px)`, background: theme.colors.accent, borderRadius: 10, boxShadow: theme.shadow.accentGlow }} />
          </div>
          <div style={{ position: "absolute", right: -40, top: -44, width: 120, height: 120, borderRadius: "50%", background: theme.colors.hero, boxShadow: theme.shadow.heroGlow, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${badge}) rotate(${interpolate(badge, [0, 1], [-60, 0])}deg)` }}>
            <IconCross size={64} color={theme.colors.white} draw={badge} />
          </div>
        </Glass>
      </div>
      <Sfx name="pop" at={card} />
      <Sfx name="click" at={strikeAt + 6} />
      <Sfx name="pop" at={strikeAt + 10} rate={1.1} vol={0.85} />
    </AbsoluteFill>
  );
};
export const SceneNotPro: React.FC = () => (
  <SceneShell id="notpro"><NotProBody /></SceneShell>
);

/* ───────────── 6. BUILT — Glossy UI: browser + phone, then the question (cues 13–15) ───────────── */
const SkeletonBrowser: React.FC<{ t: number }> = ({ t }) => {
  const frame = useCurrentFrame();
  const blocks = [0, 1, 2, 3, 4, 5];
  const b = (i: number) => prog(frame, t + 10 + i * 4, t + 24 + i * 4);
  return (
    <Glass w={1000} h={660} r={40} strong>
      <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 30px", height: 78, borderBottom: `1.5px solid ${theme.colors.border}` }}>
        {[0, 1, 2].map((i) => <div key={i} style={{ width: 16, height: 16, borderRadius: 16, background: theme.colors.textFaint }} />)}
        <div style={{ marginLeft: 20, height: 40, flex: 1, borderRadius: 20, background: theme.colors.surface, border: `1.5px solid ${theme.colors.border}` }} />
      </div>
      <div style={{ padding: 36, display: "flex", flexDirection: "column", gap: 28 }}>
        <div style={{ height: 210, borderRadius: 28, background: `linear-gradient(120deg, ${theme.colors.hero}55, ${theme.colors.accent}22)`, border: `1.5px solid ${theme.colors.border}`, opacity: b(0), transform: `scaleY(${0.8 + 0.2 * b(0)})`, padding: 36, display: "flex", flexDirection: "column", gap: 20, transformOrigin: "50% 0" }}>
          <Bar w={420} h={26} color={theme.colors.text} style={{ opacity: 0.8 }} />
          <Bar w={300} h={16} color={theme.colors.textDim} />
        </div>
        <div style={{ display: "flex", gap: 28 }}>
          {blocks.slice(1, 4).map((i) => (
            <div key={i} style={{ flex: 1, height: 190, borderRadius: 24, background: theme.colors.surface, border: `1.5px solid ${theme.colors.border}`, opacity: b(i), transform: `translateY(${(1 - b(i)) * 30}px)`, padding: 26, display: "flex", flexDirection: "column", gap: 16 }}>
              <div style={{ width: 54, height: 54, borderRadius: 16, background: theme.colors.textFaint }} />
              <Bar w="80%" h={14} />
              <Bar w="55%" h={12} />
            </div>
          ))}
        </div>
      </div>
    </Glass>
  );
};

const SkeletonPhone: React.FC<{ t: number }> = ({ t }) => {
  const frame = useCurrentFrame();
  const b = (i: number) => prog(frame, t + 10 + i * 4, t + 24 + i * 4);
  return (
    <Glass w={330} h={660} r={60} strong style={{ padding: 26 }}>
      <div style={{ width: 110, height: 24, borderRadius: 24, background: theme.colors.bg, margin: "0 auto 26px" }} />
      <div style={{ height: 150, borderRadius: 26, background: `linear-gradient(140deg, ${theme.colors.accent}33, ${theme.colors.hero}33)`, border: `1.5px solid ${theme.colors.border}`, opacity: b(0), transform: `scale(${0.9 + 0.1 * b(0)})` }} />
      {[1, 2, 3, 4].map((i) => (
        <div key={i} style={{ display: "flex", alignItems: "center", gap: 16, marginTop: 24, opacity: b(i), transform: `translateX(${(1 - b(i)) * 30}px)` }}>
          <div style={{ width: 60, height: 60, borderRadius: 18, background: theme.colors.textFaint }} />
          <div style={{ display: "flex", flexDirection: "column", gap: 12, flex: 1 }}><Bar w="90%" h={14} /><Bar w="60%" h={11} /></div>
        </div>
      ))}
    </Glass>
  );
};

const BuiltBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tb = Math.max(0, s.at(13, 0.1));
  const tp = Math.max(0, s.at(13, 0.55));
  const ck1 = s.at(14, 0), ck2 = s.at(14, 0.22);
  const dimAt = s.at(15, 0.12);
  const dim = prog(frame, dimAt, dimAt + 16);
  const pb = pop(frame, fps, tb, "smooth"), pp = pop(frame, fps, tp, "smooth");
  const f1 = useFloat(5, 28), f2 = useFloat(5, 28, 2);
  const k = [s.at(15, 0.2), s.at(15, 0.45), s.at(15, 0.72)];
  const check = (at: number) => pop(frame, fps, at, "bouncy");
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", inset: 0, opacity: 1 - dim * 0.78, filter: `blur(${dim * 7}px)`, transform: `scale(${1 - dim * 0.05})` }}>
        <div style={{ position: "absolute", left: 150, top: 240 + f1, opacity: interpolate(pb, [0, 0.5], [0, 1], clamp), transform: `translateY(${interpolate(pb, [0, 1], [60, 0])}px) scale(${interpolate(pb, [0, 1], [0.94, 1])})` }}>
          <SkeletonBrowser t={tb} />
          <div style={{ position: "absolute", left: 0, top: -92 }}><Pill size={44}>website</Pill></div>
          <div style={{ position: "absolute", right: -34, top: -34, width: 92, height: 92, borderRadius: "50%", background: theme.colors.accent, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${check(ck1)})`, boxShadow: theme.shadow.accentGlow }}>
            <IconCheck size={56} color={theme.colors.bg} draw={check(ck1)} />
          </div>
        </div>
        <div style={{ position: "absolute", left: 1290, top: 240 + f2, opacity: interpolate(pp, [0, 0.5], [0, 1], clamp), transform: `translateY(${interpolate(pp, [0, 1], [60, 0])}px) scale(${interpolate(pp, [0, 1], [0.94, 1])})` }}>
          <SkeletonPhone t={tp} />
          <div style={{ position: "absolute", left: 0, top: -92 }}><Pill size={44}>app</Pill></div>
          <div style={{ position: "absolute", right: -34, top: -34, width: 92, height: 92, borderRadius: "50%", background: theme.colors.accent, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${check(ck2)})`, boxShadow: theme.shadow.accentGlow }}>
            <IconCheck size={56} color={theme.colors.bg} draw={check(ck2)} />
          </div>
        </div>
      </div>
      {/* kinetic question */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 250, display: "flex", flexDirection: "column", alignItems: "center" }}>
        <WordReveal words={["কিন্তু"]} delays={[k[0]]} size={110} weight={theme.fonts.semi} color={theme.colors.accent} align="center" />
        <WordReveal words={["বানানোর", "পর?"]} delays={[k[1], k[2]]} size={230} align="center" highlight={{ 1: theme.colors.hero }} style={{ textShadow: `0 0 60px ${theme.colors.heroGlow}`, marginTop: -10 }} />
      </div>
      <Sfx name="pop" at={tb} />
      <Sfx name="pop" at={tp} rate={1.06} vol={0.9} />
      <Sfx name="click" at={ck1 + 2} />
      <Sfx name="click" at={ck2 + 2} rate={1.08} vol={0.9} />
      <Sfx name="thud" at={k[1]} />
    </AbsoluteFill>
  );
};
export const SceneBuilt: React.FC = () => (
  <SceneShell id="built"><BuiltBody /></SceneShell>
);
