import React from "react";
import { AbsoluteFill, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { useScene } from "../timing";
import { theme } from "../theme";
import { Avatar, IconBrowser, IconCheck, IconCross, IconLink, IconSearch } from "../components/Icons";
import { Bar, Glass, Pill, T } from "../components/Glass";
import { WordReveal, clamp, prog, useBreathe, useFloat } from "../components/Motion";
import { Sfx } from "../components/Sfx";

const pop = (frame: number, fps: number, delay: number, preset: "snappy" | "bouncy" | "smooth" = "snappy") =>
  spring({ frame: frame - delay, fps, config: theme.spring[preset] });

/* ───────────── 7. LOCALHOST — Dark Tech (cues 16–19) ───────────── */
const FRIENDS = [290, 480, 670];
const LocalhostBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tl = Math.max(0, s.at(16, 0.35));
  const tu = Math.max(0, s.at(17, 0));
  const tf = FRIENDS.map((_, k) => Math.max(0, s.at(17, 0.55) + k * 6));
  const tline = Math.max(0, s.at(18, 0));
  const tx = FRIENDS.map((_, k) => s.at(19, 0) + k * 6);
  const cap = Math.max(0, s.at(19, 0.12));
  const lp = pop(frame, fps, tl, "smooth");
  const up = pop(frame, fps, tu, "bouncy");
  const blink = Math.floor(frame / 15) % 2 === 0 ? 1 : 0.15;
  const fl = useFloat(4, 30);
  const lines = [[0.62, 0], [0.82, 1], [0.46, 0], [0.7, 1], [0.55, 0], [0.34, 1], [0.6, 0]];
  const blocked = prog(frame, tx[0], tx[0] + 10);
  return (
    <AbsoluteFill>
      {/* connections + wall */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <line x1={1230} y1={200} x2={1230} y2={760} stroke={theme.colors.textFaint} strokeWidth={4} strokeDasharray="4 16" strokeLinecap="round" opacity={prog(frame, tline, tline + 14)} />
        {FRIENDS.map((y, k) => {
          const d = prog(frame, tline + k * 4, tline + k * 4 + 16);
          const off = -frame * 3;
          const ok = prog(frame, tx[k], tx[k] + 8);
          return <line key={k} x1={1580} y1={y} x2={1580 - 340 * d} y2={y} stroke={theme.colors.accent} strokeWidth={5} strokeLinecap="round" strokeDasharray="22 16" strokeDashoffset={off} opacity={0.85 - ok * 0.6} />;
        })}
      </svg>
      {/* laptop / terminal */}
      <div style={{ position: "absolute", left: 110, top: 200 + fl, opacity: interpolate(lp, [0, 0.5], [0, 1], clamp), transform: `translateY(${interpolate(lp, [0, 1], [60, 0])}px) scale(${interpolate(lp, [0, 1], [0.94, 1])})` }}>
        <Glass w={960} h={560} r={36} strong style={{ background: "rgba(6,9,22,0.85)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 28px", height: 86, borderBottom: `1.5px solid ${theme.colors.border}` }}>
            {[0, 1, 2].map((i) => <div key={i} style={{ width: 16, height: 16, borderRadius: 16, background: theme.colors.textFaint }} />)}
            <div style={{ marginLeft: 22, display: "flex", alignItems: "center", gap: 12, padding: "6px 30px", borderRadius: 40, background: theme.colors.hero, boxShadow: up > 0.2 ? theme.shadow.heroGlow : "none", opacity: interpolate(up, [0, 0.4], [0, 1], clamp), transform: `scale(${interpolate(up, [0, 1], [0.8, 1])})`, transformOrigin: "0 50%" }}>
              <T size={46} color={theme.colors.white} weight={theme.fonts.semi}>localhost</T>
            </div>
          </div>
          <div style={{ padding: "34px 44px", display: "flex", flexDirection: "column", gap: 26 }}>
            {lines.map(([w, c], i) => {
              const p = prog(frame, tl + 10 + i * 4, tl + 22 + i * 4);
              return (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 18, opacity: p, transform: `translateX(${(1 - p) * -24}px)` }}>
                  <div style={{ width: 14, height: 14, borderRadius: 4, background: theme.colors.accent }} />
                  <Bar w={`${w * 100}%`} h={16} color={c ? theme.colors.accent : theme.colors.textDim} style={{ opacity: c ? 0.7 : 0.6 }} />
                </div>
              );
            })}
            <div style={{ width: 16, height: 30, borderRadius: 4, background: theme.colors.accent, opacity: blink, marginLeft: 32 }} />
          </div>
        </Glass>
        <div style={{ width: 1120, height: 20, marginLeft: -80, borderRadius: "0 0 40px 40px", background: theme.colors.surfaceStrong, border: `1.5px solid ${theme.colors.border}`, marginTop: 16 }} />
      </div>
      {/* friends */}
      {FRIENDS.map((y, k) => {
        const p = pop(frame, fps, tf[k], "snappy");
        const xp = pop(frame, fps, tx[k], "bouncy");
        return (
          <React.Fragment key={k}>
            <div style={{ position: "absolute", left: 1580, top: y - 70, opacity: interpolate(p, [0, 0.5], [0, 1], clamp), transform: `scale(${interpolate(p, [0, 1], [0.6, 1])})` }}>
              <Avatar size={140} tint={theme.colors.textDim} />
            </div>
            <div style={{ position: "absolute", left: 1230 - 48, top: y - 48, width: 96, height: 96, borderRadius: "50%", background: theme.colors.bgAlt, border: `3px solid ${theme.colors.accent}`, boxShadow: theme.shadow.accentGlow, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${xp})`, opacity: xp > 0.01 ? 1 : 0 }}>
              <IconCross size={52} color={theme.colors.text} draw={xp} />
            </div>
          </React.Fragment>
        );
      })}
      <div style={{ position: "absolute", left: 0, right: 0, top: 850, opacity: 1 }}>
        <WordReveal words={["ঢুকতেই", "পারেনি"]} delay={cap} per={5} size={120} align="center" highlight={{ 1: theme.colors.accent }} />
      </div>
      <Sfx name="pop" at={tl} />
      <Sfx name="pop" at={tf[0]} rate={1.08} vol={0.9} />
      {tx.map((t, k) => <Sfx key={k} name="click" at={t} rate={0.96 + k * 0.05} vol={0.9} />)}
      <Sfx name="thud" at={cap} vol={0.85} />
      <div style={{ display: "none" }}>{blocked}</div>
    </AbsoluteFill>
  );
};
export const SceneLocalhost: React.FC = () => (
  <SceneShell id="localhost"><LocalhostBody /></SceneShell>
);

/* ───────────── 8. DEPLOY — Process flow with logos (cues 20–21) ───────────── */
const LogoCard: React.FC<{ src: string; w: number; delay: number; zoom?: number }> = ({ src, w, delay, zoom = 1 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = pop(frame, fps, delay, "bouncy");
  const kb = interpolate(frame, [delay, delay + 90], [1, 1.05], { easing: theme.ease.inOut, ...clamp });
  return (
    <div style={{ opacity: interpolate(p, [0, 0.4], [0, 1], clamp), transform: `translateY(${interpolate(p, [0, 1], [50, 0])}px) scale(${interpolate(p, [0, 1], [0.7, 1])})` }}>
      <div style={{ width: 480, height: 290, borderRadius: 44, background: theme.colors.white, boxShadow: theme.shadow.card, display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}>
        <Img src={staticFile(src)} style={{ width: w * zoom, mixBlendMode: "multiply", transform: `scale(${kb})` }} />
      </div>
    </div>
  );
};

const Arrow: React.FC<{ x1: number; x2: number; y: number; t: number }> = ({ x1, x2, y, t }) => {
  const frame = useCurrentFrame();
  const d = prog(frame, t, t + 16);
  const x = x1 + (x2 - x1) * d;
  const pk = ((frame - t - 16) % 40) / 40;
  return (
    <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
      <line x1={x1} y1={y} x2={x} y2={y} stroke={theme.colors.accent} strokeWidth={6} strokeLinecap="round" />
      {d > 0.95 && <path d={`M${x2 - 22} ${y - 20} L${x2} ${y} L${x2 - 22} ${y + 20}`} stroke={theme.colors.accent} strokeWidth={6} fill="none" strokeLinecap="round" strokeLinejoin="round" />}
      {frame > t + 16 && <circle cx={x1 + (x2 - x1) * pk} cy={y} r={9} fill={theme.colors.text} opacity={Math.sin(Math.PI * pk)} />}
    </svg>
  );
};

const DeployBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tg = Math.max(0, s.spread(20, 0, 2));
  const tn = Math.max(0, s.spread(20, 1, 2));
  const tl = Math.max(0, s.at(21, 0));
  const head = Math.max(0, s.at(21, 0.1));
  const ck = s.at(21, 0.55);
  const lp = pop(frame, fps, tl, "bouncy");
  const live = 0.5 + 0.5 * Math.sin(frame / 5);
  const cp = pop(frame, fps, ck, "bouncy");
  const fl = useFloat(4, 28);
  const Y = 560;
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 0, right: 0, top: 120 }}>
        <WordReveal words={["Website", "live", "করলেন"]} delays={[head, head + 4, head + 8]} size={110} align="center" highlight={{ 1: theme.colors.accent }} />
      </div>
      <Arrow x1={590} x2={715} y={Y} t={tn - 4} />
      <Arrow x1={1205} x2={1330} y={Y} t={tl - 4} />
      <div style={{ position: "absolute", left: 130, top: Y - 145 + fl }}><LogoCard src="logos/github.png" w={380} delay={tg} /></div>
      <div style={{ position: "absolute", left: 720, top: Y - 145 - fl }}><LogoCard src="logos/netlify.png" w={350} delay={tn} /></div>
      <div style={{ position: "absolute", left: 1330, top: Y - 145 + fl, opacity: interpolate(lp, [0, 0.4], [0, 1], clamp), transform: `translateY(${interpolate(lp, [0, 1], [50, 0])}px) scale(${interpolate(lp, [0, 1], [0.7, 1])})` }}>
        <Glass w={480} h={290} r={44} strong style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 16 }}>
          <IconBrowser size={120} color={theme.colors.accent} draw={prog(frame, tl, tl + 22)} />
          <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "4px 34px", borderRadius: 50, background: theme.colors.hero, boxShadow: theme.shadow.heroGlow }}>
            <div style={{ width: 20, height: 20, borderRadius: 20, background: theme.colors.white, opacity: 0.4 + 0.6 * live }} />
            <T size={56} color={theme.colors.white}>LIVE</T>
          </div>
          <div style={{ position: "absolute", right: -30, top: -34, width: 88, height: 88, borderRadius: "50%", background: theme.colors.accent, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${cp})`, boxShadow: theme.shadow.accentGlow }}>
            <IconCheck size={54} color={theme.colors.bg} draw={cp} />
          </div>
        </Glass>
      </div>
      <Sfx name="chime" at={tg} rate={0.96} />
      <Sfx name="chime" at={tn} rate={1.08} vol={0.95} />
      <Sfx name="pop" at={tl} />
      <Sfx name="click" at={ck} />
    </AbsoluteFill>
  );
};
export const SceneDeploy: React.FC = () => (
  <SceneShell id="deploy"><DeployBody /></SceneShell>
);

/* ───────────── 9. SEARCH — Search UI that finds nothing (cues 22–24) ───────────── */
const SearchBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tLink = Math.max(0, s.at(22, 0));
  const strike = s.at(22, 0.32);
  const linkOut = s.at(22, 0.62);
  const tBar = Math.max(0, s.at(22, 0.66));
  const q = [s.at(23, 0.1), s.at(23, 0.3)];
  const rows0 = s.at(23, 0.62);
  const scan = s.at(24, 0);
  const slot = s.at(24, 0.28);
  const lp = pop(frame, fps, tLink, "smooth");
  const lo = prog(frame, linkOut, linkOut + 10, theme.ease.in);
  const st = prog(frame, strike, strike + 12, theme.ease.inOut);
  const bp = pop(frame, fps, tBar, "smooth");
  const sp = pop(frame, fps, slot, "bouncy");
  const br = useBreathe(0.02, 14);
  const ROW_H = 92, GAP = 20, TOP = 340;
  const scanRow = Math.min(3, Math.max(0, Math.floor((frame - scan) / 7)));
  const scanOn = frame >= scan && frame < scan + 32;
  return (
    <AbsoluteFill>
      {/* link ছাড়া */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 250, display: "flex", flexDirection: "column", alignItems: "center", gap: 40, opacity: (1 - lo) * interpolate(lp, [0, 0.5], [0, 1], clamp), transform: `translateY(${-lo * 50 + interpolate(lp, [0, 1], [50, 0])}px) scale(${interpolate(lp, [0, 1], [0.94, 1])})` }}>
        <WordReveal words={["নির্দিষ্ট", "link", "ছাড়া"]} delay={tLink} per={4} size={110} align="center" highlight={{ 1: theme.colors.accent }} />
        <div style={{ position: "relative" }}>
          <Glass w={1000} h={130} r={65} strong style={{ display: "flex", alignItems: "center", padding: "0 50px", gap: 30 }}>
            <IconLink size={70} color={theme.colors.accent} />
            <Bar w={560} h={20} color={theme.colors.textDim} />
          </Glass>
          <div style={{ position: "absolute", left: -20, top: 60, height: 10, width: `calc(${st * 100}% + ${40 * st}px)`, background: theme.colors.accent, borderRadius: 10, boxShadow: theme.shadow.accentGlow }} />
        </div>
      </div>
      {/* search bar */}
      <div style={{ position: "absolute", left: 340, top: 110, opacity: interpolate(bp, [0, 0.5], [0, 1], clamp), transform: `translateY(${interpolate(bp, [0, 1], [-60, 0])}px)` }}>
        <div style={{ position: "absolute", left: 0, top: -88 }}><Pill size={44}>Google</Pill></div>
        <Glass w={1240} h={130} r={65} strong style={{ display: "flex", alignItems: "center", padding: "0 54px", gap: 30 }}>
          <IconSearch size={66} color={theme.colors.accent} />
          <WordReveal words={["আপনার", "site"]} delays={q} size={62} weight={theme.fonts.semi} />
        </Glass>
      </div>
      {/* results */}
      {[0, 1, 2, 3].map((i) => {
        const p = prog(frame, rows0 + i * 5, rows0 + i * 5 + 16);
        const active = scanOn && scanRow === i;
        const dimR = prog(frame, slot - 4, slot + 10) * 0.55;
        return (
          <div key={i} style={{ position: "absolute", left: 340, top: TOP + i * (ROW_H + GAP), opacity: p * (1 - dimR), transform: `translateY(${(1 - p) * 40}px)` }}>
            <Glass w={1240} h={ROW_H} r={32} style={{ display: "flex", alignItems: "center", padding: "0 40px", gap: 28, borderColor: active ? theme.colors.accent : theme.colors.border, boxShadow: active ? theme.shadow.accentGlow : theme.shadow.card }}>
              <div style={{ width: 46, height: 46, borderRadius: 46, background: theme.colors.textFaint }} />
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}><Bar w={[520, 420, 600, 360][i]} h={16} color={theme.colors.textDim} /><Bar w={[760, 640, 700, 820][i]} h={12} /></div>
            </Glass>
          </div>
        );
      })}
      {/* the missing result */}
      <div style={{ position: "absolute", left: 340, top: TOP + 4 * (ROW_H + GAP) - 10, opacity: interpolate(sp, [0, 0.4], [0, 1], clamp), transform: `scale(${interpolate(sp, [0, 1], [0.9, 1]) * br})` }}>
        <div style={{ width: 1240, height: 124, borderRadius: 36, border: `4px dashed ${theme.colors.accent}`, display: "flex", alignItems: "center", gap: 34, padding: "0 44px", background: "rgba(0,229,195,0.06)" }}>
          <div style={{ width: 80, height: 80, borderRadius: "50%", background: theme.colors.hero, boxShadow: theme.shadow.heroGlow, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><T size={56} color={theme.colors.white} style={{ lineHeight: 1 }}>?</T></div>
          <WordReveal words={["খুঁজে", "পাওয়া", "যাবে?"]} delays={[slot + 4, slot + 8, slot + 12]} size={64} />
        </div>
      </div>
      <Sfx name="pop" at={tLink} />
      <Sfx name="click" at={strike + 6} />
      <Sfx name="pop" at={tBar} rate={1.05} vol={0.9} />
      <Sfx name="pop" at={rows0} rate={0.95} vol={0.85} />
      <Sfx name="pop" at={slot} rate={1.12} vol={0.9} />
    </AbsoluteFill>
  );
};
export const SceneSearch: React.FC = () => (
  <SceneShell id="search"><SearchBody /></SceneShell>
);
