import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { useScene } from "../timing";
import { theme } from "../theme";
import { Avatar } from "../components/Icons";
import { Bar, Glass, T } from "../components/Glass";
import { Entrance, Highlight, WordReveal, clamp, prog, useBreathe, useFloat } from "../components/Motion";
import { Sfx } from "../components/Sfx";

/* ───────────── 1. HOOK — Kinetic Typography + inbox cards (cues 1–2) ───────────── */
const InboxCard: React.FC<{ i: number; delay: number; unread?: boolean; badgeAt?: number }> = ({ i, delay, unread, badgeAt }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const bob = useFloat(4, 34, i * 1.3);
  const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
  const badge = badgeAt !== undefined ? spring({ frame: frame - badgeAt, fps, config: theme.spring.bouncy }) : 0;
  const lens = [[300, 190], [250, 150], [340, 210], [280, 170]][i];
  return (
    <div style={{ opacity: interpolate(p, [0, 0.6], [0, 1], clamp), transform: `translate(${interpolate(p, [0, 1], [140, 0])}px, ${bob}px) scale(${interpolate(p, [0, 1], [0.92, 1])})` }}>
      <Glass w={700} h={132} r={30} strong={!!badgeAt} style={{ display: "flex", alignItems: "center", padding: "0 30px", gap: 26 }}>
        <Avatar size={80} />
        <div style={{ display: "flex", flexDirection: "column", gap: 16, flex: 1 }}>
          <Bar w={lens[0]} h={18} color={theme.colors.textDim} />
          <Bar w={lens[1]} h={14} />
        </div>
        {unread && <div style={{ width: 20, height: 20, borderRadius: 20, background: theme.colors.accent, boxShadow: theme.shadow.accentGlow }} />}
        {badgeAt !== undefined && (
          <div style={{ position: "absolute", right: -34, top: -38, width: 96, height: 96, borderRadius: "50%", background: theme.colors.hero, boxShadow: theme.shadow.heroGlow, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${badge}) rotate(${interpolate(badge, [0, 1], [-40, 0])}deg)` }}>
            <T size={64} color={theme.colors.white} style={{ lineHeight: 1 }}>?</T>
          </div>
        )}
      </Glass>
    </div>
  );
};

const HookBody: React.FC = () => {
  const s = useScene();
  const cards0 = Math.max(0, s.at(1, 0.15));
  const q = Math.max(0, s.at(2, 0));
  const word = Math.max(0, s.at(1, 0.45));
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 130, top: 0, bottom: 0, width: 900, display: "flex", flexDirection: "column", justifyContent: "center", gap: 0 }}>
        <WordReveal words={["Page", "তৈরির", "পর", "থেকে"]} delay={2} per={3} size={56} weight={theme.fonts.semi} color={theme.colors.textDim} />
        <div style={{ marginTop: 6 }}>
          <Highlight delay={word + 12} thickness={14}>
            <WordReveal words={["Inbox-এ"]} delay={word} size={230} />
          </Highlight>
        </div>
        <div style={{ marginTop: 14 }}>
          <WordReveal words={["একটা", "প্রশ্ন"]} delay={q} per={5} size={150} highlight={{ 1: theme.colors.accent }} />
        </div>
      </div>
      <div style={{ position: "absolute", right: 140, top: 0, bottom: 0, display: "flex", flexDirection: "column", justifyContent: "center", gap: 30 }}>
        {[0, 1, 2, 3].map((i) => (
          <InboxCard key={i} i={i} delay={cards0 + i * 7} unread={i === 0} badgeAt={i === 2 ? Math.max(0, s.at(2, 0.25)) : undefined} />
        ))}
      </div>
      <Sfx name="pop" at={cards0} />
      <Sfx name="thud" at={q} vol={0.9} />
      <Sfx name="pop" at={s.at(2, 0.25)} rate={1.12} vol={0.9} />
    </AbsoluteFill>
  );
};
export const SceneHook: React.FC = () => (
  <SceneShell id="hook"><HookBody /></SceneShell>
);

/* ───────────── 2. QUESTION — Glossy chat UI (cues 3–5) ───────────── */
const Typing: React.FC<{ show: number; hide: number; right?: boolean }> = ({ show, hide, right }) => {
  const frame = useCurrentFrame();
  const o = prog(frame, show, show + 6) * (1 - prog(frame, hide, hide + 4));
  if (o <= 0.01) return null;
  return (
    <div style={{ position: "absolute", top: 0, [right ? "right" : "left"]: 0, opacity: o, transform: `scale(${0.9 + 0.1 * o})`, display: "flex", gap: 12, padding: "26px 34px", borderRadius: 34, background: theme.colors.surfaceStrong, border: `1.5px solid ${theme.colors.border}` }}>
      {[0, 1, 2].map((i) => (
        <div key={i} style={{ width: 16, height: 16, borderRadius: 16, background: theme.colors.textDim, opacity: 0.55 + 0.45 * Math.sin(frame / 3.5 - i * 1.1), transform: `translateY(${Math.sin(frame / 3.5 - i * 1.1) * -5}px)` }} />
      ))}
    </div>
  );
};

const Bubble: React.FC<{ at: number; right?: boolean; hero?: boolean; maxW: number; children: React.ReactNode }> = ({ at, right, hero, maxW, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - at, fps, config: theme.spring.snappy });
  return (
    <div style={{ position: "absolute", top: 0, [right ? "right" : "left"]: 0, maxWidth: maxW, opacity: interpolate(p, [0, 0.5], [0, 1], clamp), transform: `translateY(${interpolate(p, [0, 1], [30, 0])}px) scale(${interpolate(p, [0, 1], [0.88, 1])})`, transformOrigin: right ? "100% 0" : "0 0", padding: "22px 44px 26px", borderRadius: 40, borderTopLeftRadius: right ? 40 : 10, borderTopRightRadius: right ? 10 : 40, background: hero ? theme.colors.hero : theme.colors.surfaceStrong, border: hero ? "none" : `1.5px solid ${theme.colors.border}`, boxShadow: hero ? theme.shadow.heroGlow : theme.shadow.card }}>{children}</div>
  );
};

const QuestionBody: React.FC = () => {
  const s = useScene();
  const w1 = ["AI", "দিয়ে", "video", "আর", "website", "বানিয়ে", "নিজেকে", "web", "developer", "দাবি", "করছেন", "কেন?"];
  const d1 = [s.at(2, 5 / 6), ...[0, 1, 2, 3, 4].map((k) => s.spread(3, k, 5)), ...[0, 1, 2, 3, 4, 5].map((k) => s.spread(4, k, 6))].map((v) => Math.max(8, v));
  const b1 = d1[0] - 5;
  const w2 = ["এসব", "তো", "আমরাও", "বানাতে", "পারি।"];
  const d2 = w2.map((_, k) => s.at(5, 0.3 + (0.7 * k) / 5));
  const b2 = d2[0] - 5;
  const typing2 = s.at(5, 0.02);
  const win = prog(useCurrentFrame(), 0, 22);
  const br = useBreathe(0.004, 40);
  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
      <div style={{ opacity: win, transform: `translateY(${(1 - win) * 50}px) scale(${(0.94 + 0.06 * win) * br})` }}>
        <Glass w={1400} h={900} r={44}>
          <div style={{ display: "flex", alignItems: "center", gap: 22, padding: "30px 44px", borderBottom: `1.5px solid ${theme.colors.border}` }}>
            <Avatar size={68} />
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <Bar w={230} h={18} color={theme.colors.textDim} />
              <Bar w={120} h={12} />
            </div>
            <div style={{ marginLeft: "auto", width: 18, height: 18, borderRadius: 18, background: theme.colors.accent, boxShadow: theme.shadow.accentGlow }} />
          </div>
          <div style={{ padding: "38px 48px", display: "flex", flexDirection: "column", gap: 36 }}>
            <div style={{ position: "relative", height: 330 }}>
              <Typing show={2} hide={b1 + 3} />
              <Bubble at={b1} maxW={1180}>
                <WordReveal words={w1} delays={d1} size={64} weight={theme.fonts.semi} highlight={{ 7: theme.colors.accent, 8: theme.colors.accent }} rise={20} />
              </Bubble>
            </div>
            <div style={{ position: "relative", height: 170 }}>
              <Typing show={typing2} hide={b2 + 3} right />
              <Bubble at={b2} right hero maxW={1000}>
                <WordReveal words={w2} delays={d2} size={64} weight={theme.fonts.semi} color={theme.colors.white} rise={20} />
              </Bubble>
            </div>
          </div>
          <div style={{ position: "absolute", left: 48, right: 48, bottom: 34, height: 64, borderRadius: 32, background: theme.colors.surface, border: `1.5px solid ${theme.colors.border}`, display: "flex", alignItems: "center", padding: "0 30px" }}>
            <Bar w={260} h={14} />
          </div>
        </Glass>
      </div>
      <Sfx name="pop" at={b1} />
      <Sfx name="pop" at={b2} rate={1.08} vol={0.95} />
    </AbsoluteFill>
  );
};
export const SceneQuestion: React.FC = () => (
  <SceneShell id="question"><QuestionBody /></SceneShell>
);

/* ───────────── 3. WELL — Minimal statement + ripple (cues 6–7) ───────────── */
const WellBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t0 = Math.max(0, s.at(6, 0));
  const orb = spring({ frame: frame - t0, fps, config: theme.spring.bouncy });
  const br = useBreathe(0.02, 18);
  const talk = s.at(7, 0);
  const words = ["তাদের", "উদ্দেশ্যে", "বলি।"];
  const wd = words.map((_, k) => s.at(7, (0.7 * k) / 3));
  const rings = [0, 1, 2].map((k) => {
    const ph = frame - t0 - k * 26;
    if (ph < 0) return null;
    const q = (ph % 78) / 78;
    const e = theme.ease.out(q);
    return <div key={k} style={{ position: "absolute", width: (170 + e * 380) * 2, height: (170 + e * 380) * 2, borderRadius: "50%", border: `3px solid ${theme.colors.accent}`, opacity: (1 - q) * 0.5, left: "50%", top: "50%", transform: "translate(-50%, -50%)" }} />;
  });
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 0, right: 0, top: 80, height: 700 }}>
        <div style={{ position: "absolute", left: "50%", top: "50%", width: 0, height: 0 }}>{rings}</div>
        <div style={{ position: "absolute", left: "50%", top: "50%", width: 360, height: 360, marginLeft: -180, marginTop: -180, borderRadius: "50%", background: `radial-gradient(circle at 35% 30%, #8F82F5, ${theme.colors.hero} 55%, #4A3DB8)`, boxShadow: theme.shadow.heroGlow, transform: `scale(${orb * br})`, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <T size={128} color={theme.colors.white} style={{ opacity: interpolate(orb, [0.2, 0.8], [0, 1], clamp) }}>Well,</T>
        </div>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 790 }}>
        <WordReveal words={words} delays={wd} size={100} align="center" highlight={{ 2: theme.colors.accent }} />
      </div>
      <Sfx name="pop" at={t0} rate={0.95} />
      <Sfx name="swish" at={talk} />
    </AbsoluteFill>
  );
};
export const SceneWell: React.FC = () => (
  <SceneShell id="well"><WellBody /></SceneShell>
);
