import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { useScene } from "../timing";
import { theme } from "../theme";
import { IconArrowDown, IconBriefcase, IconCheck, IconCode, IconCoin, IconGauge, IconGlobe, IconLayers, IconSearch } from "../components/Icons";
import { Bar, Glass, Pill, T } from "../components/Glass";
import { WordReveal, clamp, prog, useBreathe, useFloat } from "../components/Motion";
import { Sfx } from "../components/Sfx";

const pop = (frame: number, fps: number, delay: number, preset: "snappy" | "bouncy" | "smooth" = "snappy") =>
  spring({ frame: frame - delay, fps, config: theme.spring[preset] });
const enter = (p: number, dist = 50, from = 0.92): React.CSSProperties => ({ opacity: interpolate(p, [0, 0.5], [0, 1], clamp), transform: `translateY(${interpolate(p, [0, 1], [dist, 0])}px) scale(${interpolate(p, [0, 1], [from, 1])})` });

/* ───────────── 10. BUSINESS → "আসল game" (cues 25–27) ───────────── */
const BusinessBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tPro = Math.max(0, s.at(25, 0));
  const tBr = Math.max(0, s.at(25, 0.1));
  const tAr = Math.max(0, s.at(25, 0.3));
  const tBiz = Math.max(0, s.at(25, 0.4));
  const tInc = Math.max(0, s.at(25, 0.8));
  const tQ = s.at(26, 0.4);
  const pivot = s.at(27, 0.1);
  const dim = prog(frame, pivot, pivot + 14);
  const g = [s.at(27, 0.17), s.at(27, 0.33), s.at(27, 0.8)];
  const pb = pop(frame, fps, tBr, "smooth"), pbiz = pop(frame, fps, tBiz, "snappy"), pinc = pop(frame, fps, tInc, "snappy"), pq = pop(frame, fps, tQ, "bouncy");
  const fl = useFloat(5, 26);
  const arrowD = prog(frame, tAr, tAr + 18);
  const pk = ((frame - tAr - 18) % 36) / 36;
  const bob = Math.sin(frame / 6) * 10;
  const gp = pop(frame, fps, g[1], "bouncy");
  const br = useBreathe(0.012, 18);
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", inset: 0, opacity: 1 - dim * 0.96, filter: `blur(${dim * 8}px)`, transform: `scale(${1 - dim * 0.05})` }}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 110, display: "flex", justifyContent: "center", opacity: prog(frame, tPro, tPro + 10), transform: `translateY(${(1 - prog(frame, tPro, tPro + 14)) * -30}px)` }}>
          <Pill size={74} bg="transparent" color={theme.colors.accent} style={{ borderColor: theme.colors.accent, padding: "8px 56px" }}>professionally</Pill>
        </div>
        <div style={{ position: "absolute", left: 130, top: 300 + fl, ...enter(pb, 60, 0.94) }}>
          <Glass w={680} h={440} r={40} strong>
            <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "0 26px", height: 66, borderBottom: `1.5px solid ${theme.colors.border}` }}>
              {[0, 1, 2].map((i) => <div key={i} style={{ width: 14, height: 14, borderRadius: 14, background: theme.colors.textFaint }} />)}
            </div>
            <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 22 }}>
              <div style={{ height: 150, borderRadius: 22, background: `linear-gradient(120deg, ${theme.colors.hero}40, ${theme.colors.accent}1f)`, border: `1.5px solid ${theme.colors.border}`, padding: 26, display: "flex", flexDirection: "column", gap: 16 }}><Bar w={300} h={22} color={theme.colors.text} style={{ opacity: 0.8 }} /><Bar w={210} h={14} color={theme.colors.textDim} /></div>
              <div style={{ display: "flex", gap: 20 }}>{[0, 1, 2].map((i) => <div key={i} style={{ flex: 1, height: 130, borderRadius: 20, background: theme.colors.surface, border: `1.5px solid ${theme.colors.border}` }} />)}</div>
            </div>
          </Glass>
        </div>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          <line x1={830} y1={520} x2={830 + 130 * arrowD} y2={520} stroke={theme.colors.accent} strokeWidth={6} strokeLinecap="round" strokeDasharray="4 16" />
          {arrowD > 0.95 && <path d="M938 500 L962 520 L938 540" stroke={theme.colors.accent} strokeWidth={6} fill="none" strokeLinecap="round" strokeLinejoin="round" />}
          {frame > tAr + 18 && <circle cx={830 + 130 * pk} cy={520} r={9} fill={theme.colors.text} opacity={Math.sin(Math.PI * pk)} />}
        </svg>
        <div style={{ position: "absolute", left: 880, top: 440, width: 0, height: 0 }}>
          <div style={{ width: 100, height: 100, marginLeft: -50, marginTop: -150, borderRadius: "50%", background: theme.colors.hero, boxShadow: theme.shadow.heroGlow, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${pq})` }}><T size={64} color={theme.colors.white} style={{ lineHeight: 1 }}>?</T></div>
        </div>
        <div style={{ position: "absolute", left: 1020, top: 290 - fl, ...enter(pbiz, 50, 0.9) }}>
          <Glass w={760} h={200} r={40} strong style={{ display: "flex", alignItems: "center", padding: "0 50px", gap: 40 }}>
            <IconBriefcase size={104} color={theme.colors.accent} draw={prog(frame, tBiz, tBiz + 20)} />
            <T size={84}>Business</T>
          </Glass>
        </div>
        <div style={{ position: "absolute", left: 1020, top: 530 + fl, ...enter(pinc, 50, 0.9) }}>
          <Glass w={760} h={200} r={40} strong style={{ display: "flex", alignItems: "center", padding: "0 50px", gap: 40 }}>
            <IconCoin size={104} color={theme.colors.accent} draw={prog(frame, tInc, tInc + 20)} />
            <T size={80}>আয়ের মাধ্যম</T>
          </Glass>
        </div>
      </div>
      {/* pivot: kinetic "আসল game" */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 180, display: "flex", flexDirection: "column", alignItems: "center" }}>
        <WordReveal words={["আসল"]} delays={[g[0]]} size={130} weight={theme.fonts.semi} color={theme.colors.accent} align="center" />
        <div style={{ marginTop: -18, opacity: interpolate(gp, [0, 0.4], [0, 1], clamp), transform: `scale(${interpolate(gp, [0, 1], [0.7, 1]) * br}) translateY(${interpolate(gp, [0, 1], [60, 0])}px)` }}>
          <T size={340} color={theme.colors.hero} style={{ textShadow: `0 0 80px ${theme.colors.heroGlow}, 0 0 160px ${theme.colors.heroGlow}`, lineHeight: 1.1 }}>game</T>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 28, marginTop: 6 }}>
          <div style={{ transform: `translateY(${bob}px)`, opacity: prog(frame, g[2], g[2] + 8) }}><IconArrowDown size={90} color={theme.colors.accent} draw={prog(frame, g[2], g[2] + 14)} /></div>
          <WordReveal words={["ঠিক", "এখানেই"]} delays={[g[2], g[2] + 4]} size={100} />
        </div>
      </div>
      <Sfx name="pop" at={tBr} />
      <Sfx name="pop" at={tBiz} rate={1.05} vol={0.9} />
      <Sfx name="pop" at={tInc} rate={1.1} vol={0.9} />
      <Sfx name="pop" at={tQ} rate={0.95} vol={0.85} />
      <Sfx name="swish" at={g[0]} />
      <Sfx name="thud" at={g[1]} />
    </AbsoluteFill>
  );
};
export const SceneBusiness: React.FC = () => (
  <SceneShell id="business"><BusinessBody /></SceneShell>
);

/* ───────────── 11. BENTO — four problems (cues 28–29) ───────────── */
type Tile = { x: number; y: number; w: number; label: string; key: string };
const TILES: Tile[] = [
  { x: 160, y: 170, w: 860, label: "SEO", key: "seo" },
  { x: 1060, y: 170, w: 700, label: "Domain setup", key: "domain" },
  { x: 160, y: 580, w: 700, label: "Performance", key: "perf" },
  { x: 900, y: 580, w: 860, label: "Scalable architecture", key: "scale" },
];
const TILE_H = 370;

const BentoBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = [s.spread(28, 0, 3), s.spread(28, 1, 3), s.spread(28, 2, 3), s.at(29, 0)].map((v) => Math.max(0, v));
  return (
    <AbsoluteFill>
      {TILES.map((tile, i) => {
        const p = pop(frame, fps, t[i], "smooth");
        const a = prog(frame, t[i] + 4, t[i] + 30);
        const glow = Math.max(0, 1 - prog(frame, t[i] + 4, t[i] + 34));
        const fl = Math.sin(frame / 30 + i * 1.7) * 4;
        const bars = [0.35, 0.5, 0.45, 0.7, 0.9];
        return (
          <div key={tile.key} style={{ position: "absolute", left: tile.x, top: tile.y + fl, ...enter(p, 60, 0.9) }}>
            <Glass w={tile.w} h={TILE_H} r={46} strong style={{ padding: 44, boxShadow: `${theme.shadow.card}${glow > 0.02 ? `, 0 0 ${60 * glow}px rgba(108,92,231,${0.6 * glow})` : ""}`, borderColor: glow > 0.3 ? theme.colors.hero : theme.colors.border, overflow: "hidden" }}>
              <div style={{ display: "flex", flexDirection: "column", justifyContent: "space-between", height: "100%" }}>
                <div style={{ width: 150, height: 150, borderRadius: 40, background: theme.colors.bgAlt, border: `1.5px solid ${theme.colors.border}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  {tile.key === "seo" && <IconSearch size={92} color={theme.colors.accent} draw={a} />}
                  {tile.key === "domain" && <IconGlobe size={92} color={theme.colors.accent} draw={a} />}
                  {tile.key === "perf" && <IconGauge size={96} color={theme.colors.accent} draw={a} />}
                  {tile.key === "scale" && <IconLayers size={92} color={theme.colors.accent} draw={a} />}
                </div>
                <T size={72} style={{ whiteSpace: "nowrap" }}>{tile.label}</T>
              </div>
              {/* mini visuals */}
              {tile.key === "seo" && (
                <div style={{ position: "absolute", right: 56, bottom: 52, display: "flex", alignItems: "flex-end", gap: 18, height: 220 }}>
                  {bars.map((h, k) => <div key={k} style={{ width: 40, height: 220 * h * prog(frame, t[i] + 8 + k * 4, t[i] + 26 + k * 4), borderRadius: 14, background: k === 4 ? theme.colors.accent : theme.colors.textFaint }} />)}
                </div>
              )}
              {tile.key === "domain" && (
                <div style={{ position: "absolute", right: 48, top: 56, width: 380, height: 64, borderRadius: 32, border: `1.5px solid ${theme.colors.border}`, background: theme.colors.surface, display: "flex", alignItems: "center", padding: "0 24px", gap: 14 }}>
                  <div style={{ width: 20, height: 20, borderRadius: 20, background: theme.colors.accent }} />
                  <Bar w={`${prog(frame, t[i] + 8, t[i] + 28) * 220}px`} h={14} color={theme.colors.textDim} />
                </div>
              )}
              {tile.key === "perf" && (
                <div style={{ position: "absolute", right: 48, top: 62, width: 330, height: 22, borderRadius: 22, background: theme.colors.surface, border: `1.5px solid ${theme.colors.border}`, overflow: "hidden" }}>
                  <div style={{ width: `${prog(frame, t[i] + 8, t[i] + 30) * 100}%`, height: "100%", background: theme.colors.accent, borderRadius: 22 }} />
                </div>
              )}
              {tile.key === "scale" && (
                <div style={{ position: "absolute", right: 56, top: 48, height: 168, display: "flex", alignItems: "flex-end", gap: 14 }}>
                  {[1, 2, 3, 4].map((k) => <div key={k} style={{ width: 74, height: 42 * k * prog(frame, t[i] + 6 + k * 5, t[i] + 24 + k * 5), borderRadius: 16, background: k === 4 ? theme.colors.accent : theme.colors.textFaint }} />)}
                </div>
              )}
            </Glass>
          </div>
        );
      })}
      {t.map((v, i) => <Sfx key={i} name="pop" at={v} rate={0.96 + i * 0.05} vol={0.9} />)}
    </AbsoluteFill>
  );
};
export const SceneBento: React.FC = () => (
  <SceneShell id="bento"><BentoBody /></SceneShell>
);

/* ───────────── 12. DEVELOPER — Dark tech: one developer handles everything (cues 30–31) ───────────── */
const CHIPS = 14;
const fr = (x: number) => x - Math.floor(x);
const scatter = (i: number) => ({ x: 130 + fr(Math.sin((i + 1) * 12.9898) * 43758.5453) * 1580, y: 210 + fr(Math.sin((i + 1) * 78.233) * 12345.6789) * 600 });
const ring = (i: number) => {
  const th = (i / CHIPS) * Math.PI * 2 - Math.PI / 2;
  return { x: 960 + 800 * Math.cos(th) - 45, y: 505 + 295 * Math.sin(th) - 45 };
};

const DeveloperBody: React.FC = () => {
  const s = useScene();
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tHead = Math.max(0, s.at(30, 0));
  const tWin = Math.max(0, s.at(30, 0.45));
  const tSwap = s.at(31, 0);
  const tHandle = s.at(31, 0.0);
  const chk = (i: number) => s.at(31, 0.05) + i * 3;
  const wp = pop(frame, fps, tWin, "smooth");
  const bp = pop(frame, fps, tWin + 6, "bouncy");
  const gather = spring({ frame: frame - (tWin + 2), fps, config: theme.spring.smooth });
  const swap = prog(frame, tSwap - 2, tSwap + 8);
  const fl = useFloat(5, 24);
  const code = [[0.5, 1, 0.2], [0.3, 2, 0.4], [0.65, 0, 0.3], [0.2, 2, 0.5], [0.55, 1, 0.25], [0.4, 0, 0.3], [0.7, 2, 0.2]];
  const palette = [theme.colors.accent, theme.colors.textDim, theme.colors.text];
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 0, right: 0, top: 36 }}>
        <WordReveal words={["শতটা", "বিষয়"]} delay={tHead} per={5} size={96} align="center" highlight={{ 0: theme.colors.accent }} />
      </div>
      {/* chips: scattered → ring → checked */}
      {Array.from({ length: CHIPS }).map((_, i) => {
        const a = scatter(i), b = ring(i);
        const p = pop(frame, fps, tHead + 4 + i * 2, "snappy");
        const x = a.x + (b.x - a.x) * gather, y = a.y + (b.y - a.y) * gather + Math.sin(frame / 20 + i) * (1 - gather) * 10;
        const c = pop(frame, fps, chk(i), "bouncy");
        const rot = (1 - gather) * (i % 2 ? 8 : -8);
        return (
          <div key={i} style={{ position: "absolute", left: x, top: y, width: 90, height: 90, borderRadius: 26, background: c > 0.5 ? theme.colors.accent : theme.colors.surfaceStrong, border: `1.5px solid ${theme.colors.border}`, boxShadow: theme.shadow.card, display: "flex", alignItems: "center", justifyContent: "center", opacity: interpolate(p, [0, 0.5], [0, 1], clamp), transform: `scale(${interpolate(p, [0, 1], [0.5, 1]) * (1 + (c > 0 ? 0.12 * Math.sin(Math.PI * Math.min(1, c)) : 0))}) rotate(${rot}deg)` }}>
            {c > 0.05 ? <IconCheck size={56} color={theme.colors.bg} draw={Math.min(1, c)} /> : (
              <div style={{ display: "flex", flexDirection: "column", gap: 10, width: 46 }}><Bar w="100%" h={10} color={theme.colors.textDim} /><Bar w="60%" h={10} /></div>
            )}
          </div>
        );
      })}
      {/* editor window */}
      <div style={{ position: "absolute", left: 530, top: 290 + fl, ...enter(wp, 60, 0.92) }}>
        <Glass w={860} h={440} r={36} strong style={{ background: "rgba(6,9,22,0.88)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 28px", height: 78, borderBottom: `1.5px solid ${theme.colors.border}` }}>
            {[0, 1, 2].map((i) => <div key={i} style={{ width: 16, height: 16, borderRadius: 16, background: theme.colors.textFaint }} />)}
          </div>
          <div style={{ padding: "30px 44px", display: "flex", flexDirection: "column", gap: 22 }}>
            {code.map(([w, c, ind], i) => {
              const p = prog(frame, tWin + 8 + i * 3, tWin + 20 + i * 3);
              return <div key={i} style={{ display: "flex", gap: 16, marginLeft: ind * 160, opacity: p }}><Bar w={`${w * 560 * p}px`} h={16} color={palette[c as number]} style={{ opacity: 0.75 }} /><Bar w={`${(1 - (w as number)) * 200 * p}px`} h={16} color={theme.colors.textFaint} /></div>;
            })}
          </div>
        </Glass>
        <div style={{ position: "absolute", left: -56, top: -60, width: 140, height: 140, borderRadius: "50%", background: theme.colors.hero, boxShadow: theme.shadow.heroGlow, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${bp}) rotate(${interpolate(bp, [0, 1], [-30, 0])}deg)` }}>
          <IconCode size={80} color={theme.colors.white} draw={bp} />
        </div>
      </div>
      {/* bottom text swap */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 880, height: 140 }}>
        <div style={{ position: "absolute", left: 0, right: 0, opacity: 1 - swap, transform: `translateY(${-swap * 24}px)` }}>
          <WordReveal words={["কেবল", "একজন", "developer"]} delays={[tWin, tWin + 4, tWin + 8]} size={90} align="center" highlight={{ 2: theme.colors.accent }} />
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, opacity: swap, transform: `translateY(${(1 - swap) * 24}px)` }}>
          <WordReveal words={["সঠিকভাবে", "handle"]} delays={[tHandle + 4, tHandle + 8]} size={90} align="center" highlight={{ 1: theme.colors.accent }} />
        </div>
      </div>
      <Sfx name="swish" at={tHead} />
      <Sfx name="pop" at={tWin} />
      <Sfx name="click" at={chk(0)} />
      <Sfx name="pop" at={chk(CHIPS - 1)} rate={1.12} vol={0.85} />
    </AbsoluteFill>
  );
};
export const SceneDeveloper: React.FC = () => (
  <SceneShell id="developer"><DeveloperBody /></SceneShell>
);
