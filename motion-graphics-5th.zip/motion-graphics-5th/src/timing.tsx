// All timing is derived from the SRT (src/cues.ts). Nothing is placed by hand.
import React, { createContext, useContext } from "react";
import { CUES } from "./cues";
import { FPS, LEAD, SCENE_LEAD } from "./config";

const sec2f = (s: number) => Math.round(s * FPS);
export const cueStart = (n: number) => sec2f(CUES[n - 1].start);
export const cueEnd = (n: number) => sec2f(CUES[n - 1].end);
export const TOTAL_FRAMES = Math.ceil(CUES[CUES.length - 1].end * FPS);

// Scenes = ranges of cues (boundaries sit on cue boundaries).
export type SceneDef = { id: string; from: number; to: number; ease: number };
export const SCENES: SceneDef[] = [
  { id: "hook", from: 1, to: 2, ease: 0 },
  { id: "question", from: 3, to: 5, ease: 1 },
  { id: "well", from: 6, to: 7, ease: 2 },
  { id: "admit", from: 8, to: 10, ease: 0 },
  { id: "notpro", from: 11, to: 12, ease: 1 },
  { id: "built", from: 13, to: 15, ease: 2 },
  { id: "localhost", from: 16, to: 19, ease: 0 },
  { id: "deploy", from: 20, to: 21, ease: 1 },
  { id: "search", from: 22, to: 24, ease: 2 },
  { id: "business", from: 25, to: 27, ease: 0 },
  { id: "bento", from: 28, to: 29, ease: 1 },
  { id: "developer", from: 30, to: 31, ease: 2 },
  { id: "arrive", from: 32, to: 34, ease: 0 },
  { id: "requests", from: 35, to: 36, ease: 1 },
  { id: "teaser", from: 37, to: 38, ease: 2 },
  { id: "follow", from: 39, to: 40, ease: 0 },
  { id: "end", from: 41, to: 42, ease: 1 },
];

export type SceneTiming = SceneDef & { start: number; end: number; dur: number };
export const SCENE_TIMINGS: SceneTiming[] = SCENES.map((s, i) => {
  const start = i === 0 ? 0 : cueStart(s.from) - SCENE_LEAD;
  const next = SCENES[i + 1];
  const end = next ? cueStart(next.from) - SCENE_LEAD : TOTAL_FRAMES;
  return { ...s, start, end, dur: end - start };
});

const Ctx = createContext<SceneTiming | null>(null);
export const SceneProvider: React.FC<{ scene: SceneTiming; children: React.ReactNode }> = ({ scene, children }) => (
  <Ctx.Provider value={scene}>{children}</Ctx.Provider>
);

/** Scene-local timing helpers (frames relative to the scene start). */
export const useScene = () => {
  const s = useContext(Ctx);
  if (!s) throw new Error("useScene outside SceneProvider");
  const cs = (n: number) => cueStart(n) - s.start;
  const ce = (n: number) => cueEnd(n) - s.start;
  const cd = (n: number) => cueEnd(n) - cueStart(n);
  /** local frame where an element tied to cue `n` should land: cue start + frac*duration − LEAD */
  const at = (n: number, frac = 0, lead = LEAD) => Math.round(cs(n) + frac * cd(n) - lead);
  /** k-th of `count` items spread equally across cue `n` */
  const spread = (n: number, k: number, count: number, lead = LEAD) => at(n, count <= 1 ? 0 : k / count, lead);
  return { ...s, cs, ce, cd, at, spread };
};
