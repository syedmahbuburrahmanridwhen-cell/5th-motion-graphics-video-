import React from "react";
import { AbsoluteFill } from "remotion";
import { Grade, Grain, Vignette } from "./components/Layers";
import { Transitions } from "./components/Transition";
import { PreviewAudio } from "./components/Sfx";
import { SceneHook, SceneQuestion, SceneWell } from "./scenes/Part1";
import { SceneAdmit, SceneNotPro, SceneBuilt } from "./scenes/Part2";
import { SceneLocalhost, SceneDeploy, SceneSearch } from "./scenes/Part3";
import { SceneBusiness, SceneBento, SceneDeveloper } from "./scenes/Part4";
import { SceneArrive, SceneRequests, SceneTeaser, SceneFollow, SceneEnd } from "./scenes/Part5";

export const Main: React.FC = () => (
  <AbsoluteFill style={{ background: "#0B1020" }}>
    {/* layers 1–3: mesh + assets + graphics live inside each scene */}
    <SceneHook />
    <SceneQuestion />
    <SceneWell />
    <SceneAdmit />
    <SceneNotPro />
    <SceneBuilt />
    <SceneLocalhost />
    <SceneDeploy />
    <SceneSearch />
    <SceneBusiness />
    <SceneBento />
    <SceneDeveloper />
    <SceneArrive />
    <SceneRequests />
    <SceneTeaser />
    <SceneFollow />
    <SceneEnd />
    <Transitions />
    {/* layer 4–5 */}
    <Grade />
    <Grain />
    <Vignette />
    <PreviewAudio />
  </AbsoluteFill>
);
