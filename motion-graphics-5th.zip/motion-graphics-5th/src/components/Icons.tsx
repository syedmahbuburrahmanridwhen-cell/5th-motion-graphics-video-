import React from "react";
import { theme } from "../theme";

type P = { size?: number; color?: string; stroke?: number; style?: React.CSSProperties; draw?: number };
const base = (size: number, style?: React.CSSProperties) => ({ width: size, height: size, viewBox: "0 0 48 48", fill: "none", style });
// `draw` (0..1) animates stroke-dash for line icons
const sp = (color: string, stroke: number, draw = 1) => ({ stroke: color, strokeWidth: stroke, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, pathLength: 1, strokeDasharray: 1, strokeDashoffset: 1 - draw });

export const IconPlay: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 3, style, draw = 1 }) => (
  <svg {...base(size, style)}><rect x="5" y="9" width="38" height="30" rx="8" {...sp(color, stroke, draw)} /><path d="M20 17.5v13l11-6.5z" fill={color} opacity={draw} /></svg>
);
export const IconBrowser: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 3, style, draw = 1 }) => (
  <svg {...base(size, style)}><rect x="5" y="8" width="38" height="32" rx="7" {...sp(color, stroke, draw)} /><path d="M5 17h38" {...sp(color, stroke, draw)} /><circle cx="11" cy="12.5" r="1.4" fill={color} /><circle cx="16" cy="12.5" r="1.4" fill={color} /></svg>
);
export const IconSpark: React.FC<P> = ({ size = 64, color = theme.colors.text, style }) => (
  <svg {...base(size, style)}><path d="M24 4c1.6 9.6 4.4 12.4 14 14-9.6 1.6-12.4 4.4-14 14-1.6-9.6-4.4-12.4-14-14 9.6-1.6 12.4-4.4 14-14z" fill={color} /><path d="M37 30c.7 4 1.8 5.1 5.8 5.8-4 .7-5.1 1.8-5.8 5.8-.7-4-1.8-5.1-5.8-5.8 4-.7 5.1-1.8 5.8-5.8z" fill={color} opacity=".8" /></svg>
);
export const IconCheck: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 5, style, draw = 1 }) => (
  <svg {...base(size, style)}><path d="M11 25l9 9 18-20" {...sp(color, stroke, draw)} /></svg>
);
export const IconCross: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 5, style, draw = 1 }) => (
  <svg {...base(size, style)}><path d="M13 13l22 22M35 13L13 35" {...sp(color, stroke, draw)} /></svg>
);
export const IconSearch: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 4, style, draw = 1 }) => (
  <svg {...base(size, style)}><circle cx="21" cy="21" r="12" {...sp(color, stroke, draw)} /><path d="M30 30l11 11" {...sp(color, stroke, draw)} /></svg>
);
export const IconGlobe: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 3, style, draw = 1 }) => (
  <svg {...base(size, style)}><circle cx="24" cy="24" r="18" {...sp(color, stroke, draw)} /><ellipse cx="24" cy="24" rx="8" ry="18" {...sp(color, stroke, draw)} /><path d="M6 24h36M9 14h30M9 34h30" {...sp(color, stroke, draw)} /></svg>
);
export const IconGauge: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 3.5, style, draw = 1 }) => (
  <svg {...base(size, style)}><path d="M6 34a18 18 0 1136 0" {...sp(color, stroke, draw)} /><path d="M24 34l9-12" {...sp(color, stroke + 0.5, draw)} /><circle cx="24" cy="34" r="2.6" fill={color} /></svg>
);
export const IconLayers: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 3, style, draw = 1 }) => (
  <svg {...base(size, style)}><path d="M24 6l18 9-18 9-18-9z" {...sp(color, stroke, draw)} /><path d="M6 24l18 9 18-9M6 33l18 9 18-9" {...sp(color, stroke, draw)} /></svg>
);
export const IconCode: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 4, style, draw = 1 }) => (
  <svg {...base(size, style)}><path d="M17 14L7 24l10 10M31 14l10 10-10 10M27 10l-6 28" {...sp(color, stroke, draw)} /></svg>
);
export const IconLink: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 3.5, style, draw = 1 }) => (
  <svg {...base(size, style)}><path d="M21 27a7 7 0 0010 0l6-6a7 7 0 00-10-10l-2 2" {...sp(color, stroke, draw)} /><path d="M27 21a7 7 0 00-10 0l-6 6a7 7 0 0010 10l2-2" {...sp(color, stroke, draw)} /></svg>
);
export const IconUser: React.FC<P> = ({ size = 64, color = theme.colors.text, style }) => (
  <svg {...base(size, style)}><circle cx="24" cy="17" r="8" fill={color} /><path d="M8 42c1-9 7-14 16-14s15 5 16 14z" fill={color} /></svg>
);
export const IconBell: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 3.5, style, draw = 1 }) => (
  <svg {...base(size, style)}><path d="M12 33V22a12 12 0 0124 0v11l3 4H9z" {...sp(color, stroke, draw)} /><path d="M20 41a4 4 0 008 0" {...sp(color, stroke, draw)} /></svg>
);
export const IconCoin: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 3.5, style, draw = 1 }) => (
  <svg {...base(size, style)}><circle cx="24" cy="24" r="17" {...sp(color, stroke, draw)} /><path d="M24 14v20M29 19c-1-2-3-3-5-3-3 0-5 1.6-5 4s2 3 5 4 5 2 5 4-2 4-5 4c-2 0-4-1-5-3" {...sp(color, stroke - 0.5, draw)} /></svg>
);
export const IconBriefcase: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 3.5, style, draw = 1 }) => (
  <svg {...base(size, style)}><rect x="6" y="14" width="36" height="25" rx="6" {...sp(color, stroke, draw)} /><path d="M17 14v-3a3 3 0 013-3h8a3 3 0 013 3v3M6 25h36" {...sp(color, stroke, draw)} /></svg>
);
export const IconPin: React.FC<P> = ({ size = 64, color = theme.colors.text, style }) => (
  <svg {...base(size, style)}><path d="M24 4a13 13 0 00-13 13c0 10 13 27 13 27s13-17 13-27A13 13 0 0024 4z" fill={color} /><circle cx="24" cy="17" r="5" fill="#0B1020" /></svg>
);
export const IconBulb: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 3.5, style, draw = 1 }) => (
  <svg {...base(size, style)}><path d="M17 33c0-4-6-6-6-13a13 13 0 0126 0c0 7-6 9-6 13z" {...sp(color, stroke, draw)} /><path d="M18 39h12M20 43.5h8" {...sp(color, stroke, draw)} /></svg>
);
export const IconKey: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 3.5, style, draw = 1 }) => (
  <svg {...base(size, style)}><circle cx="16" cy="28" r="9" {...sp(color, stroke, draw)} /><path d="M23 21l17-17M33 11l5 5M28 16l4 4" {...sp(color, stroke, draw)} /></svg>
);
export const IconLock: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 3.5, style, draw = 1 }) => (
  <svg {...base(size, style)}><rect x="9" y="21" width="30" height="21" rx="6" {...sp(color, stroke, draw)} /><path d="M15 21v-6a9 9 0 0118 0v6" {...sp(color, stroke, draw)} /></svg>
);
export const IconChat: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 3.5, style, draw = 1 }) => (
  <svg {...base(size, style)}><path d="M8 11h32a3 3 0 013 3v18a3 3 0 01-3 3H21l-9 8v-8H8a3 3 0 01-3-3V14a3 3 0 013-3z" {...sp(color, stroke, draw)} /></svg>
);
export const IconArrowDown: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 5, style, draw = 1 }) => (
  <svg {...base(size, style)}><path d="M24 8v30M12 27l12 12 12-12" {...sp(color, stroke, draw)} /></svg>
);
export const IconInbox: React.FC<P> = ({ size = 64, color = theme.colors.text, stroke = 3.5, style, draw = 1 }) => (
  <svg {...base(size, style)}><path d="M6 28l6-17h24l6 17v9a3 3 0 01-3 3H9a3 3 0 01-3-3z" {...sp(color, stroke, draw)} /><path d="M6 28h11a7 7 0 0014 0h11" {...sp(color, stroke, draw)} /></svg>
);

/** simple avatar disc */
export const Avatar: React.FC<{ size: number; tint?: string; style?: React.CSSProperties }> = ({ size, tint = theme.colors.textDim, style }) => (
  <div style={{ width: size, height: size, borderRadius: "50%", background: theme.colors.bgAlt, border: `2px solid ${theme.colors.border}`, display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", flexShrink: 0, ...style }}>
    <IconUser size={size * 0.78} color={tint} style={{ marginTop: size * 0.12 }} />
  </div>
);
