import React from "react";
import { theme } from "../theme";

export const Glass: React.FC<{ w?: number | string; h?: number | string; r?: number; strong?: boolean; style?: React.CSSProperties; children?: React.ReactNode }> = ({ w, h, r = theme.radius.md, strong, style, children }) => (
  <div style={{ width: w, height: h, borderRadius: r, background: strong ? theme.colors.surfaceStrong : theme.colors.surface, border: `1.5px solid ${theme.colors.border}`, boxShadow: theme.shadow.card, backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)", position: "relative", ...style }}>{children}</div>
);

/** skeleton line */
export const Bar: React.FC<{ w: number | string; h?: number; color?: string; style?: React.CSSProperties }> = ({ w, h = 14, color = theme.colors.textFaint, style }) => (
  <div style={{ width: w, height: h, borderRadius: h, background: color, ...style }} />
);

export const T: React.FC<{ size: number; weight?: number; color?: string; style?: React.CSSProperties; children?: React.ReactNode }> = ({ size, weight = theme.fonts.heavy, color = theme.colors.text, style, children }) => (
  <div style={{ fontFamily: theme.fonts.family, fontSize: size, fontWeight: weight, color, lineHeight: theme.type.lineHeight, letterSpacing: 0, ...style }}>{children}</div>
);

export const Pill: React.FC<{ size?: number; bg?: string; color?: string; style?: React.CSSProperties; children?: React.ReactNode }> = ({ size = 36, bg = theme.colors.surfaceStrong, color = theme.colors.text, style, children }) => (
  <div style={{ display: "inline-flex", alignItems: "center", gap: 12, padding: `${Math.round(size * 0.12)}px ${Math.round(size * 0.55)}px`, borderRadius: theme.radius.pill, background: bg, border: `1.5px solid ${theme.colors.border}`, fontFamily: theme.fonts.family, fontWeight: theme.fonts.semi, fontSize: size, lineHeight: theme.type.lineHeight, letterSpacing: 0, color, ...style }}>{children}</div>
);
