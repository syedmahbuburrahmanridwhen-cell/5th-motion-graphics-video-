import React, { useEffect, useState } from "react";
import { Audio, Sequence, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { SFX_ENABLED, VOICEOVER_IN_PREVIEW, VOICEOVER_IN_RENDER } from "../config";

export type SfxName = "pop" | "click" | "whoosh" | "swish" | "chime" | "thud";
// restrained base volumes (0.2–0.35): never covers the voiceover
const BASE: Record<SfxName, number> = { pop: 0.3, click: 0.24, whoosh: 0.26, swish: 0.2, chime: 0.28, thud: 0.3 };

/** One sound effect starting at scene-local frame `at` (already includes the 2–3 frame lead if wanted). */
export const Sfx: React.FC<{ name: SfxName; at: number; vol?: number; rate?: number }> = ({ name, at, vol = 1, rate = 1 }) => {
  if (!SFX_ENABLED) return null;
  return (
    <Sequence from={Math.max(0, Math.round(at))} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={BASE[name] * vol} playbackRate={rate} />
    </Sequence>
  );
};

/** Voiceover: plays public/voiceover.mp3 when the file exists; silently skipped otherwise. */
export const PreviewAudio: React.FC = () => {
  const { isRendering } = getRemotionEnvironment();
  const enabled = isRendering ? VOICEOVER_IN_RENDER : VOICEOVER_IN_PREVIEW;
  const [handle] = useState(() => (enabled ? delayRender("voiceover-check") : null));
  const [exists, setExists] = useState(false);
  useEffect(() => {
    if (!enabled || handle === null) return;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => {
        const ct = r.headers.get("content-type") || "";
        setExists(r.ok && !ct.includes("text/html"));
      })
      .catch(() => setExists(false))
      .finally(() => continueRender(handle));
  }, [enabled, handle]);
  return enabled && exists ? <Audio src={staticFile("voiceover.mp3")} /> : null;
};
