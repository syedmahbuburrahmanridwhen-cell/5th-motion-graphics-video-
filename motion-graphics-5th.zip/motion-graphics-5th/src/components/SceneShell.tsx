import React from "react";
import { AbsoluteFill, Sequence, interpolate, useCurrentFrame } from "remotion";
import { SceneProvider, SceneTiming, SCENE_TIMINGS, TOTAL_FRAMES } from "../timing";
import { BgMesh } from "./Layers";
import { theme } from "../theme";
import { clamp } from "./Motion";

const Shell: React.FC<{ s: SceneTiming; idx: number; children: React.ReactNode }> = ({ s, idx, children }) => {
  const frame = useCurrentFrame();
  // exit: faster than entrances (~7 frames)
  const e = interpolate(frame, [s.dur - 8, s.dur - 1], [0, 1], { easing: theme.ease.in, ...clamp });
  const last = s.end === TOTAL_FRAMES;
  return (
    <AbsoluteFill>
      <BgMesh v={idx} />
      <AbsoluteFill style={{ opacity: 1 - e, transform: `scale(${1 + e * (last ? 0.0 : 0.035)}) translateY(${last ? 0 : -e * 16}px)`, filter: e > 0 && !last ? `blur(${e * 5}px)` : undefined }}>{children}</AbsoluteFill>
    </AbsoluteFill>
  );
};

export const SceneShell: React.FC<{ id: string; children: React.ReactNode }> = ({ id, children }) => {
  const idx = SCENE_TIMINGS.findIndex((s) => s.id === id);
  const s = SCENE_TIMINGS[idx];
  return (
    <Sequence from={s.start} durationInFrames={s.dur} name={id}>
      <SceneProvider scene={s}>
        <Shell s={s} idx={idx}>{children}</Shell>
      </SceneProvider>
    </Sequence>
  );
};
