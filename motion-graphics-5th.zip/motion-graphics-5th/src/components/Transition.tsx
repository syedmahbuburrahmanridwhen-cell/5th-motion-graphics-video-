import React from "react";
import { AbsoluteFill, Sequence, interpolate, useCurrentFrame } from "remotion";
import { SCENE_TIMINGS } from "../timing";
import { theme } from "../theme";
import { Sfx } from "./Sfx";

const HALF = 7; // sweep spans boundary ±7 frames; the cut happens behind it at the middle

const Sweep: React.FC<{ kind: number }> = ({ kind }) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [0, HALF * 2], [0, 1], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const grad = `linear-gradient(${kind === 1 ? 0 : kind === 2 ? 270 : 90}deg, ${theme.colors.bgAlt} 0%, ${theme.colors.hero} 62%, ${theme.colors.hero} 94%, ${theme.colors.accent} 94%, ${theme.colors.accent} 100%)`;
  // kind 0: left→right, 1: bottom→top, 2: right→left
  const common: React.CSSProperties = { position: "absolute", background: grad, boxShadow: `0 0 80px ${theme.colors.heroGlow}` };
  if (kind === 0) {
    const x = -2700 + p * 4920;
    return <div style={{ ...common, top: -200, height: 1480, width: 2600, transform: `translateX(${x}px) skewX(-10deg)` }} />;
  }
  if (kind === 1) {
    const y = 1180 - p * 2980;
    return <div style={{ ...common, left: -200, width: 2320, height: 1700, transform: `translateY(${y}px) skewY(4deg)` }} />;
  }
  const x = 2020 - p * 4820;
  return <div style={{ ...common, top: -200, height: 1480, width: 2600, transform: `translateX(${x}px) skewX(10deg)` }} />;
};

/** Global overlay: one sweep per scene boundary + a smooth whoosh before the cut. */
export const Transitions: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    {SCENE_TIMINGS.slice(1).map((s, i) => (
      <Sequence key={s.id} from={s.start - HALF} durationInFrames={HALF * 2 + 1} name={`transition→${s.id}`}>
        <Sweep kind={s.ease} />
        <Sfx name="whoosh" at={0} vol={0.9 + (i % 3) * 0.08} rate={0.94 + (i % 4) * 0.04} />
      </Sequence>
    ))}
  </AbsoluteFill>
);
