import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";

// Layer 1: animated background mesh (never flat). `v` shifts the orbs per scene.
export const BgMesh: React.FC<{ v?: number }> = ({ v = 0 }) => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55 + v) * 50;
  const d2 = Math.cos(frame / 70 + v * 1.7) * 40;
  const pos = [
    { a: [-420, -380], b: [-300, -420] },
    { a: [900, -420], b: [-500, -380] },
    { a: [300, 380], b: [-200, -300] },
  ][v % 3];
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div style={{ position: "absolute", width: 1300, height: 1300, borderRadius: "50%", left: pos.a[0] + d1, top: pos.a[1], filter: "blur(60px)", background: `radial-gradient(circle, ${theme.colors.hero}40, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 1000, height: 1000, borderRadius: "50%", right: pos.b[0] - d2, bottom: pos.b[1], filter: "blur(70px)", background: `radial-gradient(circle, ${theme.colors.accent}26, transparent 65%)` }} />
      {/* faint dot grid for texture */}
      <AbsoluteFill style={{ backgroundImage: `radial-gradient(${theme.colors.textFaint} 1.2px, transparent 1.4px)`, backgroundSize: "56px 56px", opacity: 0.16, maskImage: "radial-gradient(ellipse at center, black 30%, transparent 78%)", WebkitMaskImage: "radial-gradient(ellipse at center, black 30%, transparent 78%)" }} />
    </AbsoluteFill>
  );
};

// Layer 4: colour grade (above content)
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.hero, mixBlendMode: "soft-light", opacity: 0.2 }} />
    <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 28%, transparent 72%, rgba(0,0,0,0.22))" }} />
  </AbsoluteFill>
);

// Layer 5: grain + vignette (topmost)
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px", backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.07, mixBlendMode: "overlay" }} />
  );
};
export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.3) 100%)" }} />
);
