import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** Premium entrance: opacity + rise + scale together (spring). Returns progress too. */
export const useEnter = (delay = 0, config: { damping: number; stiffness: number; mass: number } = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config });
};

export const Entrance: React.FC<{
  delay?: number; from?: "up" | "down" | "left" | "right"; dist?: number; scaleFrom?: number;
  preset?: "smooth" | "snappy" | "bouncy"; style?: React.CSSProperties; children?: React.ReactNode;
}> = ({ delay = 0, from = "up", dist = 40, scaleFrom = 0.94, preset = "smooth", style, children }) => {
  const p = useEnter(delay, theme.spring[preset]);
  const o = interpolate(p, [0, 0.6], [0, 1], clamp);
  const d = interpolate(p, [0, 1], [dist, 0]);
  const tx = from === "left" ? -d : from === "right" ? d : 0;
  const ty = from === "up" ? d : from === "down" ? -d : 0;
  return (
    <div style={{ opacity: o, transform: `translate(${tx}px, ${ty}px) scale(${interpolate(p, [0, 1], [scaleFrom, 1])})`, ...style }}>{children}</div>
  );
};

/** Bengali-safe word reveal: split ONLY on spaces; letterSpacing 0; px gap (not em). */
export const WordReveal: React.FC<{
  words: string[] | string; delays?: number[]; delay?: number; per?: number; size: number;
  weight?: number; color?: string; align?: "left" | "center" | "right"; highlight?: Record<number, string>;
  style?: React.CSSProperties; rise?: number;
}> = ({ words, delays, delay = 0, per = 4, size, weight = theme.fonts.heavy, color = theme.colors.text, align = "left", highlight = {}, style, rise = 34 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const list = Array.isArray(words) ? words : words.split(" ");
  return (
    <div style={{ display: "flex", flexWrap: "wrap", columnGap: Math.round(size * 0.26), rowGap: 0, justifyContent: align === "center" ? "center" : align === "right" ? "flex-end" : "flex-start", fontFamily: theme.fonts.family, fontWeight: weight, fontSize: size, lineHeight: theme.type.lineHeight, letterSpacing: 0, color, ...style }}>
      {list.map((w, i) => {
        const d = delays ? delays[i] : delay + i * per;
        const p = spring({ frame: frame - d, fps, config: theme.spring.snappy });
        return (
          <span key={i} style={{ display: "inline-block", opacity: interpolate(p, [0, 0.5], [0, 1], clamp), transform: `translateY(${interpolate(p, [0, 1], [rise, 0])}px) scale(${interpolate(p, [0, 1], [0.92, 1])})`, color: highlight[i] ?? color, whiteSpace: "nowrap" }}>{w}</span>
        );
      })}
    </div>
  );
};

/** Marker sweep behind/under a piece of text (accent). Wrap the text. */
export const Highlight: React.FC<{ delay: number; color?: string; thickness?: number; children: React.ReactNode; style?: React.CSSProperties }> = ({ delay, color = theme.colors.accent, thickness = 12, children, style }) => {
  const frame = useCurrentFrame();
  const w = interpolate(frame, [delay, delay + 16], [0, 100], { easing: theme.ease.out, ...clamp });
  return (
    <span style={{ position: "relative", display: "inline-block", ...style }}>
      <span style={{ position: "absolute", left: 0, bottom: 4, height: thickness, width: `${w}%`, background: color, borderRadius: thickness, opacity: 0.9 }} />
      <span style={{ position: "relative" }}>{children}</span>
    </span>
  );
};

/** Idle breathing helper */
export const useBreathe = (amp = 0.015, speed = 22, phase = 0) => {
  const frame = useCurrentFrame();
  return 1 + Math.sin(frame / speed + phase) * amp;
};
export const useFloat = (amp = 4, speed = 30, phase = 0) => {
  const frame = useCurrentFrame();
  return Math.sin(frame / speed + phase) * amp;
};

/** Progress 0..1 between frames with easing (clamped) */
export const prog = (frame: number, a: number, b: number, easing = theme.ease.out) =>
  interpolate(frame, [a, b], [0, 1], { easing, ...clamp });
export { clamp };
