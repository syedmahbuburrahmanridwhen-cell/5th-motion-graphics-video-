// theme.ts — single source of truth: colors, fonts, easings, spring presets, shape language.
import { Easing } from "remotion";

export const theme = {
  colors: {
    // User-chosen scheme: Midnight Indigo
    bg: "#0B1020",
    hero: "#6C5CE7",
    accent: "#00E5C3",
    text: "#F4F6FF",
    // neutrals derived from the scheme
    bgAlt: "#121A33",
    surface: "rgba(244, 246, 255, 0.06)",
    surfaceStrong: "rgba(244, 246, 255, 0.10)",
    border: "rgba(244, 246, 255, 0.14)",
    textDim: "#9BA6CE",
    textFaint: "rgba(244, 246, 255, 0.28)",
    heroGlow: "rgba(108, 92, 231, 0.55)",
    accentGlow: "rgba(0, 229, 195, 0.40)",
    white: "#FFFFFF",
  },
  fonts: {
    // one family for the whole video; weights vary
    family: "'Hind Siliguri', sans-serif",
    heavy: 700,
    semi: 600,
    body: 500,
  },
  radius: { sm: 16, md: 28, lg: 40, pill: 999 },
  shadow: {
    card: "0 30px 70px -24px rgba(0,0,0,0.65), 0 2px 0 rgba(255,255,255,0.05) inset",
    heroGlow: "0 0 70px rgba(108,92,231,0.55), 0 0 140px rgba(108,92,231,0.28)",
    accentGlow: "0 0 40px rgba(0,229,195,0.35)",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1), // entrances
    inOut: Easing.bezier(0.83, 0, 0.17, 1), // moves
    in: Easing.bezier(0.7, 0, 0.84, 0), // exits only
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  type: { lineHeight: 1.32, letterSpacing: 0 },
} as const;
