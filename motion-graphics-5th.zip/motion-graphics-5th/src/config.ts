// Project-wide switches.
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// Voiceover (public/voiceover.mp3). Missing file => silently skipped.
export const VOICEOVER_IN_PREVIEW = true; // plays inside Remotion Studio
export const VOICEOVER_IN_RENDER = false; // off in renders by default (SFX-only output)

// SFX
export const SFX_ENABLED = true;

// Visuals land this many frames before the related words are spoken (4–6).
export const LEAD = 5;
// A scene starts this many frames before its first cue, so the transition sweep can hide the cut.
export const SCENE_LEAD = 10;
