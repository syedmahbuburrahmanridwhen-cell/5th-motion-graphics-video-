// Offline fonts: files live in public/fonts and are registered with the FontFace API.
import { continueRender, delayRender, staticFile } from "remotion";

const BENGALI =
  "U+0951-0952,U+0964-0965,U+0980-09FE,U+1CD0,U+1CD2,U+1CD5-1CD6,U+1CD8,U+1CE1,U+1CEA,U+1CED,U+1CF2,U+1CF5-1CF7,U+200C-200D,U+20B9,U+25CC,U+A8F1";
const LATIN =
  "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD";
const LATIN_EXT =
  "U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF";

const SETS: [string, string][] = [
  ["bengali", BENGALI],
  ["latin", LATIN],
  ["latin-ext", LATIN_EXT],
];
const WEIGHTS = [500, 600, 700];

let started = false;
export const loadFonts = () => {
  if (started || typeof document === "undefined") return;
  started = true;
  const handle = delayRender("fonts");
  const jobs: Promise<unknown>[] = [];
  for (const w of WEIGHTS) {
    for (const [name, range] of SETS) {
      const face = new FontFace(
        "Hind Siliguri",
        `url(${staticFile(`fonts/hind-siliguri-${name}-${w}-normal.woff2`)}) format("woff2")`,
        { weight: String(w), unicodeRange: range, display: "block" },
      );
      jobs.push(face.load().then((f) => (document.fonts as unknown as { add: (f: FontFace) => void }).add(f)));
    }
  }
  Promise.all(jobs)
    .then(() => document.fonts.ready)
    .then(() => continueRender(handle))
    .catch((e) => {
      console.error("font load failed", e);
      continueRender(handle);
    });
};
